import { PartyDetails, PartyRole, WitnessDetails } from '../types';
import { escapeHtml } from './htmlSanitizer';

export interface FormattedPartyOutput {
  en: string;
  ta: string;
  collectiveEn: string;
  collectiveTa: string;
}

/**
 * Formats standard relation prefix and terms
 */
function getRelationPrefix(fatherName: string, age: number, dob?: string): { en: string; ta: string } {
  return {
    en: `S/o or W/o or D/o ${fatherName}`,
    ta: `தந்தை/கணவர்/பாதுகாவலர் பெயர்: ${fatherName}`
  };
}

/**
 * Formats individual parties into descriptive legal paragraphs with proper grammar.
 */
export function formatParties(
  parties: PartyDetails[],
  roleType: PartyRole
): FormattedPartyOutput {
  // Singular vs Plural labels
  let roleSingularEn = '';
  let rolePluralEn = '';
  let roleSingularTa = '';
  let rolePluralTa = '';

  switch (roleType) {
    case 'Seller':
      roleSingularEn = 'VENDOR';
      rolePluralEn = 'VENDORS';
      roleSingularTa = 'விற்பனையாளர்';
      rolePluralTa = 'விற்பனையாளர்கள்';
      break;
    case 'Buyer':
      roleSingularEn = 'PURCHASER';
      rolePluralEn = 'PURCHASERS';
      roleSingularTa = 'வாங்குபவர்';
      rolePluralTa = 'வாங்குபவர்கள்';
      break;
    case 'Donor':
      roleSingularEn = 'DONOR';
      rolePluralEn = 'DONORS';
      roleSingularTa = 'கொடையாளர்';
      rolePluralTa = 'கொடையாளர்கள்';
      break;
    case 'Donee':
      roleSingularEn = 'DONEE';
      rolePluralEn = 'DONEES';
      roleSingularTa = 'கொடைபெறுபவர்';
      rolePluralTa = 'கொடைபெறுபவர்கள்';
      break;
    case 'Settlor':
      roleSingularEn = 'SETTLOR';
      rolePluralEn = 'SETTLORS';
      roleSingularTa = 'செட்டில்மென்ட் வழங்குபவர்';
      rolePluralTa = 'செட்டில்மென்ட் வழங்குபவர்கள்';
      break;
    case 'Settlee':
      roleSingularEn = 'SETTLEE';
      rolePluralEn = 'SETTLEES';
      roleSingularTa = 'செட்டில்மென்ட் பெறுபவர்';
      rolePluralTa = 'செட்டில்மென்ட் பெறுபவர்கள்';
      break;
    case 'First Co-owner':
      roleSingularEn = 'FIRST PARTY (CO-OWNER)';
      rolePluralEn = 'FIRST PARTIES (CO-OWNERS)';
      roleSingularTa = 'முதல் பாகஸ்தர்';
      rolePluralTa = 'முதல் பாகஸ்தர்கள்';
      break;
    case 'Second Co-owner':
      roleSingularEn = 'SECOND PARTY (CO-OWNER)';
      rolePluralEn = 'SECOND PARTIES (CO-OWNERS)';
      roleSingularTa = 'இரண்டாம் பாகஸ்தர்';
      rolePluralTa = 'இரண்டாம் பாகஸ்தர்கள்';
      break;
    case 'Co-owner':
      roleSingularEn = 'CO-OWNER (COPARCENER)';
      rolePluralEn = 'CO-OWNERS (COPARCENERS)';
      roleSingularTa = 'கூட்டு உரிமையாளர் (பாகஸ்தர்)';
      rolePluralTa = 'கூட்டு உரிமையாளர்கள் (பாகஸ்தர்கள்)';
      break;
    case 'Lessor':
      roleSingularEn = 'LESSOR (LANDLORD)';
      rolePluralEn = 'LESSORS (LANDLORDS)';
      roleSingularTa = 'குத்தகைக்கு விடுபவர்';
      rolePluralTa = 'குத்தகைக்கு விடுபவர்கள்';
      break;
    case 'Lessee':
      roleSingularEn = 'LESSEE (TENANT)';
      rolePluralEn = 'LESSEES (TENANTS)';
      roleSingularTa = 'குத்தகைதாரர்';
      rolePluralTa = 'குத்தகைதாரர்கள்';
      break;
    case 'Mortgagor':
      roleSingularEn = 'MORTGAGOR (BORROWER)';
      rolePluralEn = 'MORTGAGORS (BORROWERS)';
      roleSingularTa = 'அடமானம் வைப்பவர்';
      rolePluralTa = 'அடமானம் வைப்பவர்கள்';
      break;
    case 'Mortgagee':
      roleSingularEn = 'MORTGAGEE (LENDER)';
      rolePluralEn = 'MORTGAGEES (LENDERS)';
      roleSingularTa = 'அடமானம் பெறுபவர்';
      rolePluralTa = 'அடமானம் பெறுபவர்கள்';
      break;
    case 'Principal':
      roleSingularEn = 'PRINCIPAL (EXECUTANT)';
      rolePluralEn = 'PRINCIPALS (EXECUTANTS)';
      roleSingularTa = 'முதல்வர் (அதிகாரம் வழங்குபவர்)';
      rolePluralTa = 'முதல்வர்கள் (அதிகாரம் வழங்குபவர்கள்)';
      break;
    case 'Power Agent':
      roleSingularEn = 'POWER AGENT (ATTORNEY)';
      rolePluralEn = 'POWER AGENTS (ATTORNEYS)';
      roleSingularTa = 'பொது அதிகார முகவர்';
      rolePluralTa = 'பொது அதிகார முகவர்கள்';
      break;
    default:
      roleSingularEn = 'PARTY';
      rolePluralEn = 'PARTIES';
      roleSingularTa = 'தரப்பினர்';
      rolePluralTa = 'தரப்பினர்கள்';
  }

  if (!parties || parties.length === 0) {
    return {
      en: `[No ${roleType} details entered yet]`,
      ta: `[${roleSingularTa} விபரங்கள் இன்னும் உள்ளிடப்படவில்லை]`,
      collectiveEn: roleSingularEn,
      collectiveTa: roleSingularTa
    };
  }

  const individualEnTexts = parties.map((p, idx) => {
    const rawName = p.name || '';
    const prefix = rawName.startsWith('M.') || rawName.startsWith('R.') || rawName.startsWith('S.') ? '' : 'Mr./Mrs./Ms. ';
    const safeName = escapeHtml(rawName);
    const rel = p.fatherName ? `son/daughter/wife of Mr. ${escapeHtml(p.fatherName)}` : '';
    const ageStr = p.age ? `aged about ${Number(p.age)} years` : '';
    const occStr = p.occupation ? `by occupation ${escapeHtml(p.occupation)}` : '';
    const adrStr = p.address ? `residing at ${escapeHtml(p.address)}` : '';
    const aadhStr = p.aadhaar ? `holder of Aadhaar Card bearing No. ${escapeHtml(p.aadhaar)}` : '';
    const panStr = p.pan ? `and PAN bearing No. ${escapeHtml(p.pan)}` : '';
    
    const details = [rel, ageStr, occStr, adrStr, aadhStr, panStr].filter(Boolean).join(', ');
    const label = parties.length > 1 ? `the ${idx + 1}<sup>st</sup> ${roleSingularEn}` : `the ${roleSingularEn}`;
    
    return `<strong>${prefix}${safeName}</strong>, ${details} (hereinafter called ${label})`;
  });

  const individualTaTexts = parties.map((p, idx) => {
    const safeName = escapeHtml(p.name || '');
    const rel = p.fatherName ? `தந்தை/கணவர் பெயர்: திரு. ${escapeHtml(p.fatherName)}` : '';
    const ageStr = p.age ? `சுமார் ${Number(p.age)} வயதுடைய` : '';
    const occStr = p.occupation ? `தொழில்: ${escapeHtml(p.occupation)}` : '';
    const adrStr = p.address ? `விலாசம்: ${escapeHtml(p.address)}` : '';
    const aadhStr = p.aadhaar ? `ஆதார் எண்: ${escapeHtml(p.aadhaar)}` : '';
    const panStr = p.pan ? `மற்றும் PAN எண்: ${escapeHtml(p.pan)}` : '';
    
    const details = [rel, ageStr, occStr, adrStr, aadhStr, panStr].filter(Boolean).join(', ');
    const label = parties.length > 1 ? `${idx + 1}வது ${roleSingularTa}` : `${roleSingularTa}`;
    
    return `<strong>திரு/திருமதி ${safeName}</strong>, ${details} (இனிமேல் இவரை இப்பத்திரத்தில் "<strong>${label}</strong>" என்று குறிப்பிடப்படும்)`;
  });

  let enResult = '';
  let taResult = '';

  if (parties.length === 1) {
    enResult = individualEnTexts[0];
    taResult = individualTaTexts[0];
  } else {
    enResult = individualEnTexts.map((text, i) => `(${i + 1}) ${text}`).join(' AND ');
    enResult += ` (hereinafter collectively referred to as the <strong>${rolePluralEn}</strong>, which expression shall unless repugnant to the context mean and include their respective heirs, legal representatives, executors, administrators, and assigns).`;

    taResult = individualTaTexts.map((text, i) => `(${i + 1}) ${text}`).join(' மற்றும் ');
    taResult += ` (இனிமேல் இவர்கள் அனைவரும் கூட்டாக "<strong>${rolePluralTa}</strong>" என்று அழைக்கப்படுவார்கள். இந்த சொற்றொடர் இவர்களின் சட்டபூர்வமான வாரிசுகள் மற்றும் பிரதிநிதிகளையும் குறிக்கும்).`;
  }

  return {
    en: enResult,
    ta: taResult,
    collectiveEn: parties.length > 1 ? rolePluralEn : roleSingularEn,
    collectiveTa: parties.length > 1 ? rolePluralTa : roleSingularTa
  };
}

/**
 * Formats witnesses list
 */
export function formatWitnesses(witnesses: WitnessDetails[]): { en: string; ta: string } {
  if (!witnesses || witnesses.length === 0) {
    return {
      en: 'No witnesses added. Minimum of two witnesses are legally required for sub-registry execution.',
      ta: 'சாட்சிகள் இன்னும் சேர்க்கப்படவில்லை. பத்திரம் பதிவு செய்ய குறைந்தபட்சம் இரண்டு சாட்சிகள் சட்டப்படி அவசியமாகும்.'
    };
  }

  const enList = witnesses.map((w, idx) => {
    const safeName = escapeHtml(w.name || '');
    const parent = w.fatherName ? `S/o or D/o Mr. ${escapeHtml(w.fatherName)}` : '';
    const age = w.age ? `aged about ${Number(w.age)} years` : '';
    const addr = w.address ? `residing at ${escapeHtml(w.address)}` : '';
    const idProofStr = w.idProof ? `ID Proof: ${escapeHtml(w.idProof)}` : '';
    const details = [parent, age, addr, idProofStr].filter(Boolean).join(', ');
    return `<strong>${idx + 1}. ${safeName}</strong>, ${details}.`;
  });

  const taList = witnesses.map((w, idx) => {
    const safeName = escapeHtml(w.name || '');
    const parent = w.fatherName ? `தந்தை பெயர்: திரு. ${escapeHtml(w.fatherName)}` : '';
    const age = w.age ? `சுமார் ${Number(w.age)} வயதுடைய` : '';
    const addr = w.address ? `முகவரி: ${escapeHtml(w.address)}` : '';
    const idProofStr = w.idProof ? `அடையாள அட்டை: ${escapeHtml(w.idProof)}` : '';
    const details = [parent, age, addr, idProofStr].filter(Boolean).join(', ');
    return `<strong>${idx + 1}. திரு/திருமதி ${safeName}</strong>, ${details}.`;
  });

  return {
    en: enList.join('<br/><br/>'),
    ta: taList.join('<br/><br/>')
  };
}
