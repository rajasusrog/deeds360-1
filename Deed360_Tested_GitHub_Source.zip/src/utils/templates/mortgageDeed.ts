import { DeedWizardState } from '../../types';
import { formatParties, formatWitnesses } from '../partyFormatter';
import { generatePropertySchedule } from '../propertyScheduleGenerator';
import { formatIndianCurrency, numberToIndianWords } from '../amountFormatter';
import { generateClausesSection } from '../clauseInjectionEngine';
import { partitionPartiesForDeedType } from '../deedTypes';
import { escapeTemplateField, escapeNarrative } from './templateUtils';

export function generateMortgageDeed(state: DeedWizardState) {
  const { grantors, grantees } = partitionPartiesForDeedType(state.parties, 'MORTGAGE');

  const mortgagorsFormatted = formatParties(grantors, 'Mortgagor');
  const mortgageesFormatted = formatParties(grantees, 'Mortgagee');
  const scheduleFormatted = generatePropertySchedule(
    state.property,
    state.survey,
    state.surveys,
    state.extent,
    state.boundary,
    'SCHEDULE OF MORTGAGED PROPERTY (SCHEDULE "A")',
    'அடமானச் சொத்து விவரம் (அட்டவணை "A")'
  );
  const clausesFormatted = generateClausesSection(state.selectedClauses, state);
  const witnessesFormatted = formatWitnesses(state.witnesses);

  const loanAmountStr = formatIndianCurrency(state.transaction.considerationAmount);
  const loanAmountWords = numberToIndianWords(state.transaction.considerationAmount);

  const dateStr = state.transaction.paymentDate || new Date().toISOString().split('T')[0];
  const parsedDate = new Date(dateStr);
  const formattedEnglishDate = isNaN(parsedDate.getTime())
    ? dateStr
    : parsedDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

  return [
    {
      id: 'title',
      titleEn: 'Deed Title',
      titleTa: 'பத்திரத் தலைப்பு',
      contentEn: '<h2 class="text-center font-bold underline text-slate-900 text-sm">DEED OF SIMPLE MORTGAGE</h2>',
      contentTa: '<h2 class="text-center font-bold underline text-slate-900 text-sm">அடமானப் பத்திரம்</h2>'
    },
    {
      id: 'intro',
      titleEn: 'Introductory Declaration',
      titleTa: 'அறிமுகப் பிரகடனம்',
      contentEn: `This DRAFT DEED OF SIMPLE MORTGAGE is prepared for execution at <strong>${escapeTemplateField(state.property.sro)}</strong> on this <strong>${formattedEnglishDate}</strong>.`,
      contentTa: `இந்த அடமானப் பத்திர வரைவு <strong>${escapeTemplateField(state.property.sro)}</strong> சார்பதிவக எல்லைக்குள் <strong>${formattedEnglishDate}</strong> அன்று எழுதப்பட்டது.`
    },
    {
      id: 'parties',
      titleEn: 'Description of Mortgagor & Mortgagee',
      titleTa: 'அடமானம் வைப்பவர் மற்றும் அடமானம் பெறுபவர் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>BY AND BETWEEN:</strong></p>
          <p>${mortgagorsFormatted.en}</p>
          <p class="font-bold py-1">AND</p>
          <p>${mortgageesFormatted.en}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>அடமானம் வைப்பவர் மற்றும் அடமானம் பெறுபவர் விவரம்:</strong></p>
          <p>${mortgagorsFormatted.ta}</p>
          <p class="font-bold py-1">மற்றும்</p>
          <p>${mortgageesFormatted.ta}</p>
        </div>
      `
    },
    {
      id: 'recitals',
      titleEn: 'Recitals & Declared Ownership History',
      titleTa: 'சொத்து வரலாறு & கடன் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>WHEREAS (AS REPRESENTED BY THE MORTGAGOR):</strong></p>
          <p>1. The MORTGAGOR represents that they hold title to the scheduled property described hereunder, citing prior <strong>${escapeTemplateField(state.ownershipHistory.parentDocType) || 'Parent Deed'}</strong> bearing Document No. <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong>.</p>
          <p>2. The MORTGAGOR has requested the MORTGAGEE to advance a loan of <strong>${loanAmountStr}</strong>, and has agreed to execute a simple mortgage of the Scheduled Property as security for the repayment of the said loan. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>சொத்து வரலாறு விவரம்:</strong></p>
          <p>1. இவ்வடமானப் பத்திரத்தில் விவரிக்கப்பட்டுள்ள சொத்தானது அடமானம் வைப்பவருக்கு முந்தைய ஆவண எண் <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> (சார்பதிவகம்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>) மூலம் உரிமை உள்ளதாக அறிவிக்கப்படுகிறது.</p>
          <p>2. அடமானம் வைப்பவர் தனது தேவைக்காக அடமானம் பெறுபவரிடம் இருந்து <strong>${loanAmountStr}</strong> கடனாகப் பெற விண்ணப்பித்து, அதற்குப் பிணையமாக இச்சொத்தினை அடமானம் வைக்க உடன்படுகிறார். ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `
    },
    {
      id: 'transaction',
      titleEn: 'Mortgage Terms & Declared Loan Particulars',
      titleTa: 'அடமான நிபந்தனைகள் மற்றும் கடன் விவரங்கள்',
      contentEn: `
        <div class="space-y-2">
          <p>NOW THIS DEED WITNESSETH that in consideration of the declared principal loan sum of <strong>${loanAmountStr}</strong> (${loanAmountWords}), the MORTGAGOR hereby charges and mortgages the Scheduled Property hereunder unto the MORTGAGEE as security for repayment:</p>
          <ul class="list-disc pl-5">
            <li>Declared Loan Principal Amount: <strong>${loanAmountStr}</strong> (${loanAmountWords})</li>
            <li>Declared Disbursement Mode: <strong>${escapeTemplateField(state.transaction.paymentMode)}</strong></li>
            <li>Declared Transaction Reference: <strong>${escapeTemplateField(state.transaction.paymentRefNo)}</strong></li>
            <li>Declared Bank / Institution: <strong>${escapeTemplateField(state.transaction.bankName)}</strong></li>
          </ul>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதன்படி, அறிவிக்கப்பட்ட அசல் கடன் தொகையான <strong>${loanAmountStr}</strong> (${loanAmountWords}) க்கு பிணையமாக இச்சொத்தின் மீதான அடமானப் பொறுப்பை அடமானம் வைப்பவர் அடமானம் பெறுபவருக்கு எழுதிக் கொடுக்க உடன்படுகிறார்:</p>
          <ul class="list-disc pl-5">
            <li>அறிவிக்கப்பட்ட அசல் கடன் தொகை: <strong>${loanAmountStr}</strong></li>
            <li>கடன் வழங்கும் முறை: <strong>${escapeTemplateField(state.transaction.paymentMode)}</strong></li>
            <li>பரிவர்த்தனை குறிப்பு எண்: <strong>${escapeTemplateField(state.transaction.paymentRefNo)}</strong></li>
            <li>வங்கி / நிறுவனம்: <strong>${escapeTemplateField(state.transaction.bankName)}</strong></li>
          </ul>
        </div>
      `
    },
    {
      id: 'clauses',
      titleEn: 'Covenants & Clauses',
      titleTa: 'உடன்படிக்கைகள் மற்றும் நிபந்தனைகள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>THE MORTGAGOR AND MORTGAGEE MUTUALLY COVENANT AS FOLLOWS:</strong></p>
          ${clausesFormatted.en}
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>தரப்பினரின் உடன்படிக்கைகள் பின்வருமாறு:</strong></p>
          ${clausesFormatted.ta}
        </div>
      `
    },
    {
      id: 'schedule',
      titleEn: 'Property Schedule Description',
      titleTa: 'சொத்து அட்டவணை விவரம்',
      contentEn: scheduleFormatted.en,
      contentTa: scheduleFormatted.ta
    },
    {
      id: 'witnesses',
      titleEn: 'Witness Attestation Section',
      titleTa: 'சாட்சிகள் உறுதிப்பகுதி',
      contentEn: `
        <div class="space-y-2">
          <p>IN WITNESS WHEREOF, the MORTGAGOR and the MORTGAGEE have set their hands to this Mortgage Deed in the presence of the following witnesses:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.en}
          </div>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதற்குச் சாட்சியாக, அடமானம் வைப்பவரும் அடமானம் பெறுபவரும் இவ்வடமானப் பத்திரத்தில் கீழ் குறிப்பிட்ட சாட்சிகளின் முன்னிலையில் கையொப்பமிடுகின்றனர்:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.ta}
          </div>
        </div>
      `
    },
    {
      id: 'signatures',
      titleEn: 'Signatures Block',
      titleTa: 'கையொப்பப் பகுதி',
      contentEn: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">MORTGAGOR (BORROWER)</p>
            <p className="text-slate-500 mt-8">Name: ${mortgagorsFormatted.collectiveEn}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">MORTGAGEE (LENDER)</p>
            <p className="text-slate-500 mt-8">Name: ${mortgageesFormatted.collectiveEn}</p>
          </div>
        </div>
      `,
      contentTa: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">அடமானம் வைப்பவர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${mortgagorsFormatted.collectiveTa}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">அடமானம் பெறுபவர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${mortgageesFormatted.collectiveTa}</p>
          </div>
        </div>
      `
    }
  ];
}
