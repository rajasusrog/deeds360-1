import { DeedWizardState } from '../../types';
import { formatParties, formatWitnesses } from '../partyFormatter';
import { generatePropertySchedule } from '../propertyScheduleGenerator';
import { formatIndianCurrency, numberToIndianWords } from '../amountFormatter';
import { generateClausesSection } from '../clauseInjectionEngine';
import { partitionPartiesForDeedType } from '../deedTypes';
import { escapeTemplateField, escapeNarrative } from './templateUtils';

export function generateSettlementDeed(state: DeedWizardState) {
  const { grantors, grantees } = partitionPartiesForDeedType(state.parties, 'SETTLEMENT');

  const settlorsFormatted = formatParties(grantors, 'Settlor');
  const settleesFormatted = formatParties(grantees, 'Settlee');
  const scheduleFormatted = generatePropertySchedule(
    state.property,
    state.survey,
    state.surveys,
    state.extent,
    state.boundary,
    'SCHEDULE OF SETTLED PROPERTY (SCHEDULE "A")',
    'செட்டில்மென்ட் சொத்து விவரம் (அட்டவணை "A")'
  );
  const clausesFormatted = generateClausesSection(state.selectedClauses, state);
  const witnessesFormatted = formatWitnesses(state.witnesses);

  const marketValStr = formatIndianCurrency(state.transaction.marketValue);
  const marketValWords = numberToIndianWords(state.transaction.marketValue);

  const dateStr = state.transaction.paymentDate || new Date().toISOString().split('T')[0];
  const parsedDate = new Date(dateStr);
  const formattedEnglishDate = isNaN(parsedDate.getTime())
    ? dateStr
    : parsedDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

  return [
    {
      id: 'title',
      titleEn: 'Deed Title',
      titleTa: 'பத்திரத் தலைப்பு',
      contentEn: '<h2 class="text-center font-bold underline text-slate-900 text-sm">DEED OF FAMILY SETTLEMENT</h2>',
      contentTa: '<h2 class="text-center font-bold underline text-slate-900 text-sm">குடும்ப செட்டில்மென்ட் பத்திரம்</h2>'
    },
    {
      id: 'intro',
      titleEn: 'Introductory Declaration',
      titleTa: 'அறிமுகப் பிரகடனம்',
      contentEn: `This DRAFT DEED OF FAMILY SETTLEMENT is prepared for execution at <strong>${escapeTemplateField(state.property.sro)}</strong> on this <strong>${formattedEnglishDate}</strong>.`,
      contentTa: `இந்த குடும்ப செட்டில்மென்ட் பத்திர வரைவு <strong>${escapeTemplateField(state.property.sro)}</strong> சார்பதிவக எல்லைக்குள் <strong>${formattedEnglishDate}</strong> அன்று எழுதப்பட்டது.`
    },
    {
      id: 'parties',
      titleEn: 'Description of Parties',
      titleTa: 'தரப்பினர் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>BY AND BETWEEN:</strong></p>
          <p>${settlorsFormatted.en}</p>
          <p class="font-bold py-1">AND</p>
          <p>${settleesFormatted.en}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>செட்டில்மென்ட் வழங்குபவர் மற்றும் செட்டில்மென்ட் பெறுபவர்:</strong></p>
          <p>${settlorsFormatted.ta}</p>
          <p class="font-bold py-1">மற்றும்</p>
          <p>${settleesFormatted.ta}</p>
        </div>
      `
    },
    {
      id: 'recitals',
      titleEn: 'Recitals & Declared Ownership History',
      titleTa: 'சொத்து வரலாறு & முந்தைய விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>WHEREAS (AS REPRESENTED BY THE SETTLOR):</strong></p>
          <p>1. The SETTLOR represents that they hold title to the scheduled property described hereunder, citing prior <strong>${escapeTemplateField(state.ownershipHistory.parentDocType, 'Parent Deed')}</strong> bearing Document No. <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> of year <strong>${escapeTemplateField(state.ownershipHistory.parentDocYear)}</strong> at <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>.</p>
          <p>2. The SETTLEE is a family member of the SETTLOR, and the SETTLOR out of natural love and affection intends to settle the scheduled property in favor of the SETTLEE without monetary consideration.</p>
          <p>3. Declared prior owners: <strong>${escapeTemplateField(state.ownershipHistory.priorOwners)}</strong>. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>சொத்து வரலாறு விவரம் (செட்டில்மென்ட் வழங்குபவர் பிரகடனம்):</strong></p>
          <p>1. இக்குடும்ப செட்டில்மென்ட் பத்திரத்தில் விவரிக்கப்பட்டுள்ள சொத்தானது செட்டில்மென்ட் வழங்குபவருக்கு <strong>${escapeTemplateField(state.ownershipHistory.parentDocDate)}</strong> தேதியிட்ட <strong>${escapeTemplateField(state.ownershipHistory.parentDocType, 'மூல ஆவணம்')}</strong>, ஆவண எண் <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)} / ${escapeTemplateField(state.ownershipHistory.parentDocYear)}</strong> (சார்பதிவகம்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>) மூலம் உரிமை பெற்றதாக அறிவிக்கப்படுகிறது.</p>
          <p>2. செட்டில்மென்ட் பெறுபவர், செட்டில்மென்ட் வழங்குபவரின் குடும்ப உறுப்பினர் ஆவார். குடும்ப அன்பு மற்றும் பாசத்தின் அடிப்படையில் எவ்வித பணப் பிரதிபலனுமின்றி இச்சொத்தினை செட்டில்மென்ட் செய்து கொடுக்க விரும்புகிறார்.</p>
          <p>3. அறிவிக்கப்பட்ட முந்தைய உரிமையாளர்: <strong>${escapeTemplateField(state.ownershipHistory.priorOwners)}</strong>. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `
    },
    {
      id: 'transaction',
      titleEn: 'Settlement Terms & Declared Valuation',
      titleTa: 'செட்டில்மென்ட் விவரம் மற்றும் சொத்து மதிப்பு',
      contentEn: `
        <div class="space-y-2">
          <p>NOW THIS DEED WITNESSETH that in consideration of natural love and affection, the SETTLOR hereby agrees to settle and transfer the Scheduled Property hereunder unto the SETTLEE.</p>
          <p>The declared Market Value of the Scheduled Property for stamp duty calculation is <strong>${marketValStr}</strong> (${marketValWords}). No monetary consideration is exchanged under this family settlement.</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>குடும்ப அன்பு மற்றும் பாசத்தின் அடிப்படையில், செட்டில்மென்ட் வழங்குபவர் இச்சொத்தினை செட்டில்மென்ட் பெறுபவருக்கு எவ்வித பணப் பிரதிபலனுமின்றி ஏற்பாடு செய்து கொடுக்க உடன்படுகிறார்.</p>
          <p>முத்திரைத்தாள் கணக்கீட்டிற்காக அறிவிக்கப்பட்ட சொத்தின் சந்தை மதிப்பு <strong>${marketValStr}</strong> (${marketValWords}). இப்பத்திரத்தின் கீழ் எவ்வித பணப் பரிவர்த்தனையும் நடைபெறவில்லை.</p>
        </div>
      `
    },
    {
      id: 'clauses',
      titleEn: 'Covenants & Clauses',
      titleTa: 'உடன்படிக்கைகள் மற்றும் நிபந்தனைகள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>THE SETTLOR AND SETTLEE HEREBY COVENANT AS FOLLOWS:</strong></p>
          ${clausesFormatted.en}
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>தரப்பினரின் உடன்படிக்கைகள் பின்வருமாறு:</strong></p>
          ${clausesFormatted.ta}
        </div>
      `
    },
    {
      id: 'schedule',
      titleEn: 'Property Schedule Description',
      titleTa: 'சொத்து அட்டவணை விவரம்',
      contentEn: scheduleFormatted.en,
      contentTa: scheduleFormatted.ta
    },
    {
      id: 'witnesses',
      titleEn: 'Witness Attestation Section',
      titleTa: 'சாட்சிகள் உறுதிப்பகுதி',
      contentEn: `
        <div class="space-y-2">
          <p>IN WITNESS WHEREOF, the SETTLOR and SETTLEE have set their hands to this Family Settlement Deed in the presence of the following witnesses:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.en}
          </div>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதற்குச் சாட்சியாக, செட்டில்மென்ட் வழங்குபவரும் பெறுபவரும் இக்குடும்ப செட்டில்மென்ட் பத்திரத்தில் கீழ் குறிப்பிட்ட சாட்சிகளின் முன்னிலையில் கையொப்பமிடுகின்றனர்:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.ta}
          </div>
        </div>
      `
    },
    {
      id: 'signatures',
      titleEn: 'Signatures Block',
      titleTa: 'கையொப்பப் பகுதி',
      contentEn: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">SETTLOR (SETTLING PARTY)</p>
            <p className="text-slate-500 mt-8">Name: ${settlorsFormatted.collectiveEn}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">SETTLEE (BENEFICIARY)</p>
            <p className="text-slate-500 mt-8">Name: ${settleesFormatted.collectiveEn}</p>
          </div>
        </div>
      `,
      contentTa: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">செட்டில்மென்ட் வழங்குபவர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${settlorsFormatted.collectiveTa}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">செட்டில்மென்ட் பெறுபவர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${settleesFormatted.collectiveTa}</p>
          </div>
        </div>
      `
    }
  ];
}
