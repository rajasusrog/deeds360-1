import { DeedWizardState } from '../../types';
import { formatParties, formatWitnesses } from '../partyFormatter';
import { generatePropertySchedule } from '../propertyScheduleGenerator';
import { formatIndianCurrency, numberToIndianWords } from '../amountFormatter';
import { generateClausesSection } from '../clauseInjectionEngine';
import { partitionPartiesForDeedType } from '../deedTypes';
import { escapeTemplateField, escapeNarrative } from './templateUtils';

export function generateLeaseDeed(state: DeedWizardState) {
  const { grantors, grantees } = partitionPartiesForDeedType(state.parties, 'LEASE');

  const lessorsFormatted = formatParties(grantors, 'Lessor');
  const lesseesFormatted = formatParties(grantees, 'Lessee');
  const scheduleFormatted = generatePropertySchedule(
    state.property,
    state.survey,
    state.surveys,
    state.extent,
    state.boundary,
    'SCHEDULE OF LEASED DEMISED PREMISES (SCHEDULE "A")',
    'குத்தகைச் சொத்து விவரம் (அட்டவணை "A")'
  );
  const clausesFormatted = generateClausesSection(state.selectedClauses, state);
  const witnessesFormatted = formatWitnesses(state.witnesses);

  const rentStr = formatIndianCurrency(state.transaction.considerationAmount);
  const rentWords = numberToIndianWords(state.transaction.considerationAmount);
  const depositStr = formatIndianCurrency(state.transaction.advancePaid || 0);
  const depositWords = numberToIndianWords(state.transaction.advancePaid || 0);

  const dateStr = state.transaction.paymentDate || new Date().toISOString().split('T')[0];
  const parsedDate = new Date(dateStr);
  const formattedEnglishDate = isNaN(parsedDate.getTime())
    ? dateStr
    : parsedDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

  return [
    {
      id: 'title',
      titleEn: 'Deed Title',
      titleTa: 'பத்திரத் தலைப்பு',
      contentEn: '<h2 class="text-center font-bold underline text-slate-900 text-sm">DEED OF LEASE</h2>',
      contentTa: '<h2 class="text-center font-bold underline text-slate-900 text-sm">வாடகை / குத்தகைப் பத்திரம்</h2>'
    },
    {
      id: 'intro',
      titleEn: 'Introductory Declaration',
      titleTa: 'அறிமுகப் பிரகடனம்',
      contentEn: `This DRAFT DEED OF LEASE is prepared for execution at <strong>${escapeTemplateField(state.property.sro)}</strong> on this <strong>${formattedEnglishDate}</strong>.`,
      contentTa: `இந்த வாடகை / குத்தகைப் பத்திர வரைவு <strong>${escapeTemplateField(state.property.sro)}</strong> சார்பதிவக எல்லைக்குள் <strong>${formattedEnglishDate}</strong> அன்று எழுதப்பட்டது.`
    },
    {
      id: 'parties',
      titleEn: 'Description of Lessor & Lessee',
      titleTa: 'குத்தகைக்கு விடுபவர் மற்றும் குத்தகைதாரர் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>BY AND BETWEEN:</strong></p>
          <p>${lessorsFormatted.en}</p>
          <p class="font-bold py-1">AND</p>
          <p>${lesseesFormatted.en}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>குத்தகைக்கு விடுபவர் மற்றும் குத்தகைதாரர் விவரம்:</strong></p>
          <p>${lessorsFormatted.ta}</p>
          <p class="font-bold py-1">மற்றும்</p>
          <p>${lesseesFormatted.ta}</p>
        </div>
      `
    },
    {
      id: 'recitals',
      titleEn: 'Recitals & Declared Ownership History',
      titleTa: 'சொத்து வரலாறு & குத்தகை பின்னணி',
      contentEn: `
        <div class="space-y-2">
          <p><strong>WHEREAS (AS REPRESENTED BY THE LESSOR):</strong></p>
          <p>1. The LESSOR represents that they are entitled to lease the scheduled demised premises described hereunder, citing Document No. <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> at SRO <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>.</p>
          <p>2. The LESSEE has requested the LESSOR to grant a lease of the Scheduled Property, and the LESSOR has agreed to lease the same on the terms and conditions set out hereunder. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>சொத்து வரலாறு விவரம்:</strong></p>
          <p>1. இக்குத்தகைப் பத்திரத்தில் விவரிக்கப்பட்டுள்ள சொத்தானது குத்தகைக்கு விடுபவருக்கு முந்தைய ஆவண எண் <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> (சார்பதிவகம்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>) மூலம் உரிமை உள்ளதாக அறிவிக்கப்படுகிறது.</p>
          <p>2. குத்தகைதாரர் இச்சொத்தினை குத்தகைக்கு எடுக்கக் கோரியதன் அடிப்படையில் கீழ் குறிப்பிட்ட நிபந்தனைகளுக்கு உட்பட்டு குத்தகைக்கு விட உடன்படப்படுகிறது. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `
    },
    {
      id: 'transaction',
      titleEn: 'Lease Rent & Security Deposit Terms',
      titleTa: 'வாடகை நிபந்தனைகள் மற்றும் காப்புத் தொகை',
      contentEn: `
        <div class="space-y-2">
          <p>NOW THIS DEED WITNESSETH that the LESSOR hereby agrees to demise and lease the Scheduled Property unto the LESSEE on the following declared terms:</p>
          <ul class="list-disc pl-5">
            <li>Declared Monthly Lease Rent: <strong>${rentStr}</strong> (${rentWords}) per month.</li>
            <li>Declared Security Deposit / Advance: <strong>${depositStr}</strong> (${depositWords}).</li>
            <li>Declared Commencement Date: <strong>${escapeTemplateField(state.transaction.paymentDate)}</strong>.</li>
            <li>Declared Payment Mode: <strong>${escapeTemplateField(state.transaction.paymentMode)}</strong> (Ref: <strong>${escapeTemplateField(state.transaction.paymentRefNo)}</strong>).</li>
          </ul>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதன்படி, குத்தகைக்கு விடுபவர் இச்சொத்தினை குத்தகைதாரருக்கு பின்வரும் அறிவிக்கப்பட்ட நிபந்தனைகளுக்கு உட்பட்டு குத்தகைக்கு விட உடன்படுகிறார்:</p>
          <ul class="list-disc pl-5">
            <li>அறிவிக்கப்பட்ட மாதாந்திர வாடகைத் தொகை: <strong>${rentStr}</strong> (${rentWords}).</li>
            <li>அறிவிக்கப்பட்ட காப்புத் தொகை / முன்பணம்: <strong>${depositStr}</strong> (${depositWords}).</li>
            <li>குத்தகை தொடங்கும் தேதி: <strong>${escapeTemplateField(state.transaction.paymentDate)}</strong>.</li>
            <li>செலுத்தும் முறை: <strong>${escapeTemplateField(state.transaction.paymentMode)}</strong> (குறிப்பு எண்: <strong>${escapeTemplateField(state.transaction.paymentRefNo)}</strong>).</li>
          </ul>
        </div>
      `
    },
    {
      id: 'clauses',
      titleEn: 'Covenants & Clauses',
      titleTa: 'உடன்படிக்கைகள் மற்றும் நிபந்தனைகள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>THE LESSOR AND LESSEE MUTUALLY COVENANT AS FOLLOWS:</strong></p>
          ${clausesFormatted.en}
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>தரப்பினரின் உடன்படிக்கைகள் பின்வருமாறு:</strong></p>
          ${clausesFormatted.ta}
        </div>
      `
    },
    {
      id: 'schedule',
      titleEn: 'Property Schedule Description',
      titleTa: 'சொத்து அட்டவணை விவரம்',
      contentEn: scheduleFormatted.en,
      contentTa: scheduleFormatted.ta
    },
    {
      id: 'witnesses',
      titleEn: 'Witness Attestation Section',
      titleTa: 'சாட்சிகள் உறுதிப்பகுதி',
      contentEn: `
        <div class="space-y-2">
          <p>IN WITNESS WHEREOF, the LESSOR and the LESSEE have set their hands to this Lease Deed in the presence of the following witnesses:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.en}
          </div>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதற்குச் சாட்சியாக, குத்தகைக்கு விடுபவரும் குத்தகைதாரரும் இக்குத்தகைப் பத்திரத்தில் கீழ் குறிப்பிட்ட சாட்சிகளின் முன்னிலையில் கையொப்பமிடுகின்றனர்:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.ta}
          </div>
        </div>
      `
    },
    {
      id: 'signatures',
      titleEn: 'Signatures Block',
      titleTa: 'கையொப்பப் பகுதி',
      contentEn: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">LESSOR (LANDLORD)</p>
            <p className="text-slate-500 mt-8">Name: ${lessorsFormatted.collectiveEn}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">LESSEE (TENANT)</p>
            <p className="text-slate-500 mt-8">Name: ${lesseesFormatted.collectiveEn}</p>
          </div>
        </div>
      `,
      contentTa: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">குத்தகைக்கு விடுபவர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${lessorsFormatted.collectiveTa}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">குத்தகைதாரர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${lesseesFormatted.collectiveTa}</p>
          </div>
        </div>
      `
    }
  ];
}
