import { DeedWizardState } from '../../types';
import { formatParties, formatWitnesses } from '../partyFormatter';
import { generatePropertySchedule } from '../propertyScheduleGenerator';
import { formatIndianCurrency, numberToIndianWords } from '../amountFormatter';
import { generateClausesSection } from '../clauseInjectionEngine';
import { partitionPartiesForDeedType } from '../deedTypes';
import { escapeTemplateField, escapeNarrative } from './templateUtils';

export function generateSaleDeed(state: DeedWizardState) {
  const { grantors, grantees } = partitionPartiesForDeedType(state.parties, 'SALE');
  const sellersFormatted = formatParties(grantors, 'Seller');
  const buyersFormatted = formatParties(grantees, 'Buyer');
  const scheduleFormatted = generatePropertySchedule(
    state.property,
    state.survey,
    state.surveys,
    state.extent,
    state.boundary,
    'SCHEDULE OF THE PROPERTY (SCHEDULE "A")',
    'சொத்து விவர அட்டவணை (அட்டவணை "A")'
  );
  const clausesFormatted = generateClausesSection(state.selectedClauses, state);
  const witnessesFormatted = formatWitnesses(state.witnesses);

  const marketValStr = formatIndianCurrency(state.transaction.marketValue);
  const marketValWords = numberToIndianWords(state.transaction.marketValue);

  const considerationStr = formatIndianCurrency(state.transaction.considerationAmount);
  const considerationWords = numberToIndianWords(state.transaction.considerationAmount);

  const advancePaidStr = formatIndianCurrency(state.transaction.advancePaid || 0);
  const advancePaidWords = numberToIndianWords(state.transaction.advancePaid || 0);

  const balancePaidStr = formatIndianCurrency(state.transaction.balancePaid || 0);
  const balancePaidWords = numberToIndianWords(state.transaction.balancePaid || 0);

  const dateStr = state.transaction.paymentDate || new Date().toISOString().split('T')[0];
  const parsedDate = new Date(dateStr);
  const formattedEnglishDate = isNaN(parsedDate.getTime())
    ? dateStr
    : parsedDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

  return [
    {
      id: 'title',
      titleEn: 'Deed Title',
      titleTa: 'பத்திரத் தலைப்பு',
      contentEn: '<h2 class="text-center font-bold underline text-slate-900 text-sm">DEED OF ABSOLUTE SALE</h2>',
      contentTa: '<h2 class="text-center font-bold underline text-slate-900 text-sm">சுத்த கிரயப் பத்திரம்</h2>'
    },
    {
      id: 'intro',
      titleEn: 'Introductory Declaration',
      titleTa: 'அறிமுகப் பிரகடனம்',
      contentEn: `This DRAFT DEED OF ABSOLUTE SALE is prepared for execution at <strong>${escapeTemplateField(state.property.sro)}</strong> on this <strong>${formattedEnglishDate}</strong>.`,
      contentTa: `இந்த சுத்த கிரயப் பத்திர வரைவு <strong>${escapeTemplateField(state.property.sro)}</strong> சார்பதிவக எல்லைக்குள் <strong>${formattedEnglishDate}</strong> அன்று எழுதப்பட்டது.`
    },
    {
      id: 'parties',
      titleEn: 'Description of Parties',
      titleTa: 'தரப்பினர் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>BY AND BETWEEN:</strong></p>
          <p>${sellersFormatted.en}</p>
          <p class="font-bold py-1">AND</p>
          <p>${buyersFormatted.en}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>எழுதிக் கொடுப்பவர் (விற்பனையாளர்) மற்றும் எழுதி வாங்குபவர்:</strong></p>
          <p>${sellersFormatted.ta}</p>
          <p class="font-bold py-1">மற்றும்</p>
          <p>${buyersFormatted.ta}</p>
        </div>
      `
    },
    {
      id: 'recitals',
      titleEn: 'Recitals & Declared Ownership History',
      titleTa: 'சொத்து வரலாறு & முந்தைய ஆவண விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>WHEREAS (AS REPRESENTED BY THE VENDOR):</strong></p>
          <p>1. The VENDOR represents that they hold title to the scheduled property described herein, citing prior registered <strong>${escapeTemplateField(state.ownershipHistory.parentDocType, 'Parent Deed')}</strong> bearing Document No. <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> of year <strong>${escapeTemplateField(state.ownershipHistory.parentDocYear)}</strong>, at Sub-Registrar Office <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>, dated <strong>${escapeTemplateField(state.ownershipHistory.parentDocDate)}</strong>.</p>
          <p>2. Declared prior ownership record: <strong>${escapeTemplateField(state.ownershipHistory.priorOwners)}</strong>.</p>
          <p>3. ${escapeNarrative(state.ownershipHistory.historyNarrative, '[No additional title narrative provided by parties.]')}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>சொத்து வரலாறு விவரம் (விற்பனையாளர் பிரகடனம்):</strong></p>
          <p>1. இக்கிரயப் பத்திரத்தில் விவரிக்கப்பட்டுள்ள சொத்தானது விற்பனையாளருக்கு <strong>${escapeTemplateField(state.ownershipHistory.parentDocDate)}</strong> தேதியிட்ட <strong>${escapeTemplateField(state.ownershipHistory.parentDocType, 'மூல ஆவணம்')}</strong>, ஆவண எண் <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)} / ${escapeTemplateField(state.ownershipHistory.parentDocYear)}</strong> (சார்பதிவகம்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>) மூலம் உரிமை பெற்றதாக விற்பனையாளரால் அறிவிக்கப்படுகிறது.</p>
          <p>2. அறிவிக்கப்பட்ட முந்தைய உரிமையாளர் விவரம்: <strong>${escapeTemplateField(state.ownershipHistory.priorOwners)}</strong>.</p>
          <p>3. ${escapeNarrative(state.ownershipHistory.historyNarrative, '[கூடுதல் சொத்து வரலாறு விவரங்கள் உள்ளிடப்படவில்லை.]')}</p>
        </div>
      `
    },
    {
      id: 'transaction',
      titleEn: 'Transaction Terms & Consideration',
      titleTa: 'பரிவர்த்தனை மற்றும் கிரயத் தொகை',
      contentEn: `
        <div class="space-y-2">
          <p>NOW THIS DEED WITNESSETH that in pursuance of the agreement of sale between the parties, the VENDOR agrees to convey and transfer the scheduled property to the PURCHASER for a declared sale consideration of <strong>${considerationStr}</strong> (${considerationWords}), with a declared market value of <strong>${marketValStr}</strong> (${marketValWords}).</p>
          <p>The declared payment particulars are as follows:</p>
          <ul class="list-disc pl-5">
            <li>Declared Advance Amount: <strong>${advancePaidStr}</strong> (${advancePaidWords})</li>
            <li>Declared Balance Consideration: <strong>${balancePaidStr}</strong> (${balancePaidWords})</li>
            <li>Declared Mode of Payment: <strong>${escapeTemplateField(state.transaction.paymentMode)}</strong></li>
            <li>Declared Transaction Reference / Instrument No: <strong>${escapeTemplateField(state.transaction.paymentRefNo)}</strong></li>
            <li>Declared Payment Date: <strong>${escapeTemplateField(state.transaction.paymentDate)}</strong> through <strong>${escapeTemplateField(state.transaction.bankName)}</strong></li>
          </ul>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இரு தரப்பினருக்கும் இடையிலான விற்பனை உடன்பாட்டின்படி, விற்பனையாளர் இச்சொத்தினை வாங்குபவருக்கு அறிவிக்கப்பட்ட கிரயத் தொகையான <strong>${considerationStr}</strong> (${considerationWords}) க்கு கிரயம் செய்து கொடுக்க உடன்படுகிறார் (அறிவிக்கப்பட்ட சந்தை மதிப்பு: <strong>${marketValStr}</strong>).</p>
          <p>அறிவிக்கப்பட்ட பணப் பரிவர்த்தனை விவரங்கள் பின்வருமாறு:</p>
          <ul class="list-disc pl-5">
            <li>அறிவிக்கப்பட்ட முன்பணம்: <strong>${advancePaidStr}</strong> (${advancePaidWords})</li>
            <li>அறிவிக்கப்பட்ட மீதமுள்ள கிரயத் தொகை: <strong>${balancePaidStr}</strong> (${balancePaidWords})</li>
            <li>பணம் செலுத்தும் முறை: <strong>${escapeTemplateField(state.transaction.paymentMode)}</strong></li>
            <li>பரிவர்த்தனை குறிப்பு எண்: <strong>${escapeTemplateField(state.transaction.paymentRefNo)}</strong></li>
            <li>தேதி: <strong>${escapeTemplateField(state.transaction.paymentDate)}</strong>, வங்கி: <strong>${escapeTemplateField(state.transaction.bankName)}</strong></li>
          </ul>
        </div>
      `
    },
    {
      id: 'tax_encumbrance',
      titleEn: 'Declared Tax, EC & Fee Particulars',
      titleTa: 'அறிவிக்கப்பட்ட வில்லங்கம், வரி மற்றும் கட்டண விவரங்கள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>DECLARED SUPPORTING REFERENCES & ESTIMATED FEES (SUBJECT TO SRO VERIFICATION):</strong></p>
          <ul class="list-disc pl-5 text-slate-700 leading-relaxed">
            <li><strong>Declared Encumbrance Certificate (EC) Ref:</strong> <strong>${state.transaction.ecReference || 'Not provided'}</strong> dated <strong>${state.transaction.ecDate || 'Not provided'}</strong> (Subject to official Sub-Registrar verification).</li>
            <li><strong>Declared Property Tax Receipt Ref:</strong> <strong>${state.transaction.propertyTaxReceipt || 'Not provided'}</strong> (Subject to municipal verification).</li>
            <li><strong>Estimated / Declared Stamp Duty:</strong> <strong>${formatIndianCurrency(state.transaction.stampDuty || 0)}</strong> (${numberToIndianWords(state.transaction.stampDuty || 0)}).</li>
            <li><strong>Estimated / Declared Registration Fee:</strong> <strong>${formatIndianCurrency(state.transaction.registrationFee || 0)}</strong> (${numberToIndianWords(state.transaction.registrationFee || 0)}).</li>
          </ul>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>அறிவிக்கப்பட்ட ஆவணக் குறிப்புகள் மற்றும் உத்தேசக் கட்டணங்கள் (சார்பதிவாளர் சரிபார்ப்புக்கு உட்பட்டது):</strong></p>
          <ul class="list-disc pl-5 text-slate-700 leading-relaxed">
            <li><strong>அறிவிக்கப்பட்ட வில்லங்கச் சான்று (EC) எண்:</strong> <strong>${state.transaction.ecReference || 'உள்ளிடப்படவில்லை'}</strong>, தேதி: <strong>${state.transaction.ecDate || 'உள்ளிடப்படவில்லை'}</strong>.</li>
            <li><strong>அறிவிக்கப்பட்ட சொத்து வரி ரசீது எண்:</strong> <strong>${state.transaction.propertyTaxReceipt || 'உள்ளிடப்படவில்லை'}</strong>.</li>
            <li><strong>உத்தேச முத்திரைத்தாள் கட்டணம்:</strong> <strong>${formatIndianCurrency(state.transaction.stampDuty || 0)}</strong> (${numberToIndianWords(state.transaction.stampDuty || 0)}).</li>
            <li><strong>உத்தேச பதிவுக் கட்டணம்:</strong> <strong>${formatIndianCurrency(state.transaction.registrationFee || 0)}</strong> (${numberToIndianWords(state.transaction.registrationFee || 0)}).</li>
          </ul>
        </div>
      `
    },
    {
      id: 'clauses',
      titleEn: 'Covenants & Clauses',
      titleTa: 'உடன்படிக்கைகள் மற்றும் நிபந்தனைகள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>THE VENDOR AND PURCHASER HEREBY COVENANT AS FOLLOWS:</strong></p>
          ${clausesFormatted.en}
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>தரப்பினரின் உடன்படிக்கைகள் பின்வருமாறு:</strong></p>
          ${clausesFormatted.ta}
        </div>
      `
    },
    {
      id: 'schedule',
      titleEn: 'Property Schedule Description',
      titleTa: 'சொத்து அட்டவணை விவரம்',
      contentEn: scheduleFormatted.en,
      contentTa: scheduleFormatted.ta
    },
    {
      id: 'witnesses',
      titleEn: 'Witness Attestation Section',
      titleTa: 'சாட்சிகள் உறுதிப்பகுதி',
      contentEn: `
        <div class="space-y-2">
          <p>IN WITNESS WHEREOF, the VENDOR and the PURCHASER have set their hands to this Deed of Absolute Sale on the day, month, and year first above written in the presence of the following witnesses:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.en}
          </div>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதற்குச் சாட்சியாக, விற்பனையாளரும் வாங்குபவரும் தங்களின் முழு சம்மதத்துடன் இக்கிரயப் பத்திரத்தில் மேற்கண்ட தேதியில் கீழ் குறிப்பிட்ட சாட்சிகளின் முன்னிலையில் கையொப்பமிடுகின்றனர்:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.ta}
          </div>
        </div>
      `
    },
    {
      id: 'signatures',
      titleEn: 'Signatures Block',
      titleTa: 'கையொப்பப் பகுதி',
      contentEn: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">VENDOR (SELLER)</p>
            <p className="text-slate-500 mt-8">Name: ${sellersFormatted.collectiveEn}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">VENDEE (PURCHASER)</p>
            <p className="text-slate-500 mt-8">Name: ${buyersFormatted.collectiveEn}</p>
          </div>
        </div>
      `,
      contentTa: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">எழுதிக் கொடுப்பவர் (விற்பனையாளர்)</p>
            <p className="text-slate-500 mt-8">பெயர்: ${sellersFormatted.collectiveTa}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">எழுதி வாங்குபவர் (வாங்குபவர்)</p>
            <p className="text-slate-500 mt-8">பெயர்: ${buyersFormatted.collectiveTa}</p>
          </div>
        </div>
      `
    }
  ];
}
