import { escapeHtml } from '../htmlSanitizer';

/**
 * Escapes a plain-text value before insertion into legal HTML templates,
 * returning a safe fallback (default '————') if empty or undefined.
 */
export function escapeTemplateField(val: unknown, fallback: string = '————'): string {
  if (val === null || val === undefined || String(val).trim() === '') {
    return fallback;
  }
  return escapeHtml(String(val).trim());
}

/**
 * Escapes narrative or multi-line text, preserving line breaks safely.
 */
export function escapeNarrative(val: unknown, fallback: string = ''): string {
  if (val === null || val === undefined || String(val).trim() === '') {
    return fallback;
  }
  return escapeHtml(String(val).trim()).replace(/\n/g, '<br/>');
}
