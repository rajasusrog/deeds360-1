import { DeedWizardState } from '../../types';
import { formatParties, formatWitnesses } from '../partyFormatter';
import { generatePropertySchedule } from '../propertyScheduleGenerator';
import { formatIndianCurrency, numberToIndianWords } from '../amountFormatter';
import { generateClausesSection } from '../clauseInjectionEngine';
import { partitionPartiesForDeedType } from '../deedTypes';
import { escapeTemplateField, escapeNarrative } from './templateUtils';

export function generatePowerOfAttorney(state: DeedWizardState) {
  const { grantors, grantees } = partitionPartiesForDeedType(state.parties, 'POA');

  const principalsFormatted = formatParties(grantors, 'Principal');
  const agentsFormatted = formatParties(grantees, 'Power Agent');
  const scheduleFormatted = generatePropertySchedule(
    state.property,
    state.survey,
    state.surveys,
    state.extent,
    state.boundary,
    'SCHEDULE OF PROPERTY UNDER AGENCY MANDATE (SCHEDULE "A")',
    'அதிகாரப் பத்திரச் சொத்து விவரம் (அட்டவணை "A")'
  );
  const clausesFormatted = generateClausesSection(state.selectedClauses, state);
  const witnessesFormatted = formatWitnesses(state.witnesses);

  const valuationStr = formatIndianCurrency(state.transaction.marketValue || 0);
  const valuationWords = numberToIndianWords(state.transaction.marketValue || 0);

  const dateStr = state.transaction.paymentDate || new Date().toISOString().split('T')[0];
  const parsedDate = new Date(dateStr);
  const formattedEnglishDate = isNaN(parsedDate.getTime())
    ? dateStr
    : parsedDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

  return [
    {
      id: 'title',
      titleEn: 'Deed Title',
      titleTa: 'பத்திரத் தலைப்பு',
      contentEn: '<h2 class="text-center font-bold underline text-slate-900 text-sm">GENERAL POWER OF ATTORNEY</h2>',
      contentTa: '<h2 class="text-center font-bold underline text-slate-900 text-sm">பொது அதிகாரப் பத்திரம் (General POA)</h2>'
    },
    {
      id: 'intro',
      titleEn: 'Introductory Declaration',
      titleTa: 'அறிமுகப் பிரகடனம்',
      contentEn: `This DRAFT GENERAL POWER OF ATTORNEY is prepared for execution at <strong>${escapeTemplateField(state.property.sro)}</strong> on this <strong>${formattedEnglishDate}</strong>.`,
      contentTa: `இந்த பொது அதிகாரப் பத்திர வரைவு <strong>${escapeTemplateField(state.property.sro)}</strong> சார்பதிவக எல்லைக்குள் <strong>${formattedEnglishDate}</strong> அன்று எழுதப்பட்டது.`
    },
    {
      id: 'parties',
      titleEn: 'Description of Principal & Power Agent',
      titleTa: 'முதல்வர் மற்றும் பொது அதிகார முகவர் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>BY AND BETWEEN:</strong></p>
          <p>${principalsFormatted.en}</p>
          <p class="font-bold py-1">AND</p>
          <p>${agentsFormatted.en}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>முதல்வர் மற்றும் பொது அதிகார முகவர் விவரம்:</strong></p>
          <p>${principalsFormatted.ta}</p>
          <p class="font-bold py-1">மற்றும்</p>
          <p>${agentsFormatted.ta}</p>
        </div>
      `
    },
    {
      id: 'recitals',
      titleEn: 'Recitals & Declared Ownership History',
      titleTa: 'சொத்து வரலாறு & அதிகார நியமனப் பின்னணி',
      contentEn: `
        <div class="space-y-2">
          <p><strong>WHEREAS (AS REPRESENTED BY THE PRINCIPAL):</strong></p>
          <p>1. The PRINCIPAL represents that they hold title to the scheduled property described hereunder, citing Document No. <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> at SRO <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>.</p>
          <p>2. As the PRINCIPAL is unable to personally attend to the administration and management of the Scheduled Property, the PRINCIPAL intends to appoint the POWER AGENT to act as lawful attorney on their behalf without transfer of ownership title. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>சொத்து வரலாறு விவரம்:</strong></p>
          <p>1. இப்பொது அதிகாரப் பத்திரத்தில் விவரிக்கப்பட்டுள்ள சொத்தானது முதல்வருக்கு முந்தைய ஆவண எண் <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> (சார்பதிவகம்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>) மூலம் உரிமை உள்ளதாக அறிவிக்கப்படுகிறது.</p>
          <p>2. முதல்வர் நேரில் சென்று இச்சொத்தினை நிர்வகிக்க இயலாத காரணத்தால், தங்களுக்குப் பதிலாகச் செயல்பட பொது அதிகார முகவரை நியமிக்க உடன்படுகிறார். ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `
    },
    {
      id: 'transaction',
      titleEn: 'Power of Attorney Mandate & Scope of Authority',
      titleTa: 'வழங்கப்படும் அதிகாரங்கள் மற்றும் பொறுப்புகள்',
      contentEn: `
        <div class="space-y-2">
          <p>NOW THIS DEED WITNESSETH that the PRINCIPAL hereby appoints, constitutes, and nominates the POWER AGENT to do the following acts, deeds, and things in the name and on behalf of the PRINCIPAL:</p>
          <ul class="list-decimal pl-5">
            <li>To manage, maintain, and protect the Scheduled Property on behalf of the Principal.</li>
            <li>To represent the Principal before the Sub-Registrar Office, Revenue Authorities, Municipal Corporation, and statutory authorities.</li>
            <li>To execute applications, agreements, and instruments as lawfully authorized by the Principal, and to maintain true and accurate accounts of all dealings.</li>
            <li>To pay municipal taxes, utility charges, and statutory outgoings relating to the Scheduled Property.</li>
          </ul>
          <p>No monetary consideration or title transfer occurs by virtue of this agency mandate. Declared property value for reference: <strong>${valuationStr}</strong> (${valuationWords}).</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதன்படி, முதல்வர் தனக்குப் பதிலாகத் தன் சார்பில் சொத்தினை நிர்வகிக்க பின்வரும் அதிகாரங்களை பொது அதிகார முகவருக்கு வழங்குகிறார்:</p>
          <ul class="list-decimal pl-5">
            <li>முதல்வர் சார்பில் சொத்தினைப் பராமரிக்கவும் பாதுகாக்கவும் அதிகாரம்.</li>
            <li>சார்பதிவகம், வருவாய்த்துறை, மாநகராட்சி மற்றும் அரசு அலுவலகங்களில் முதல்வர் சார்பில் ஆஜராகி விண்ணப்பிக்க அதிகாரம்.</li>
            <li>முதல்வரின் சட்டப்பூர்வ அறிவுறுத்தலின்படி ஆவணங்களைச் செயல்படுத்தி முறையான கணக்குகளைப் பராமரிக்க அதிகாரம்.</li>
            <li>சொத்து வரி மற்றும் இதர உள்ளாட்சி வரிகளைச் செலுத்த அதிகாரம்.</li>
          </ul>
          <p>இந்த அதிகாரப் பத்திரத்தின் மூலம் சொத்துரிமை மாற்றமோ பணப் பரிமாற்றமோ நடைபெறவில்லை. குறிப்புக்கான சொத்து மதிப்பு: <strong>${valuationStr}</strong> (${valuationWords}).</p>
        </div>
      `
    },
    {
      id: 'clauses',
      titleEn: 'Covenants & Clauses',
      titleTa: 'உடன்படிக்கைகள் மற்றும் நிபந்தனைகள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>THE PRINCIPAL AND POWER AGENT COVENANT AS FOLLOWS:</strong></p>
          ${clausesFormatted.en}
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>தரப்பினரின் உடன்படிக்கைகள் பின்வருமாறு:</strong></p>
          ${clausesFormatted.ta}
        </div>
      `
    },
    {
      id: 'schedule',
      titleEn: 'Property Schedule Description',
      titleTa: 'சொத்து அட்டவணை விவரம்',
      contentEn: scheduleFormatted.en,
      contentTa: scheduleFormatted.ta
    },
    {
      id: 'witnesses',
      titleEn: 'Witness Attestation Section',
      titleTa: 'சாட்சிகள் உறுதிப்பகுதி',
      contentEn: `
        <div class="space-y-2">
          <p>IN WITNESS WHEREOF, the PRINCIPAL and POWER AGENT have set their hands to this General Power of Attorney in the presence of the following witnesses:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.en}
          </div>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதற்குச் சாட்சியாக, முதல்வரும் பொது அதிகார முகவரும் இப்பொது அதிகாரப் பத்திரத்தில் கீழ் குறிப்பிட்ட சாட்சிகளின் முன்னிலையில் கையொப்பமிடுகின்றனர்:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.ta}
          </div>
        </div>
      `
    },
    {
      id: 'signatures',
      titleEn: 'Signatures Block',
      titleTa: 'கையொப்பப் பகுதி',
      contentEn: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">PRINCIPAL (EXECUTANT)</p>
            <p className="text-slate-500 mt-8">Name: ${principalsFormatted.collectiveEn}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">POWER AGENT (ATTORNEY)</p>
            <p className="text-slate-500 mt-8">Name: ${agentsFormatted.collectiveEn}</p>
          </div>
        </div>
      `,
      contentTa: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">முதல்வர் (அதிகாரம் வழங்குபவர்)</p>
            <p className="text-slate-500 mt-8">பெயர்: ${principalsFormatted.collectiveTa}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">பொது அதிகார முகவர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${agentsFormatted.collectiveTa}</p>
          </div>
        </div>
      `
    }
  ];
}
