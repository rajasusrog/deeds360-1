import { DeedWizardState } from '../../types';
import { formatParties, formatWitnesses } from '../partyFormatter';
import { generatePropertySchedule } from '../propertyScheduleGenerator';
import { formatIndianCurrency, numberToIndianWords } from '../amountFormatter';
import { generateClausesSection } from '../clauseInjectionEngine';
import { partitionPartiesForDeedType } from '../deedTypes';
import { escapeTemplateField, escapeNarrative } from './templateUtils';

export function generatePartitionDeed(state: DeedWizardState) {
  let { grantors: party1, grantees: party2 } = partitionPartiesForDeedType(state.parties, 'PARTITION');
  if (party1.length === 0 && state.parties.length > 0) {
    party1 = [state.parties[0]];
  }
  if (party2.length === 0 && state.parties.length > 1) {
    party2 = state.parties.slice(1);
  }

  const party1Formatted = formatParties(party1, 'First Co-owner');
  const party2Formatted = formatParties(party2, 'Second Co-owner');
  const scheduleFormatted = generatePropertySchedule(
    state.property,
    state.survey,
    state.surveys,
    state.extent,
    state.boundary,
    'SCHEDULE OF PARTITIONED PROPERTY (SCHEDULE "A")',
    'பாகப்பிரிவினை சொத்து விவரம் (அட்டவணை "A")'
  );
  const clausesFormatted = generateClausesSection(state.selectedClauses, state);
  const witnessesFormatted = formatWitnesses(state.witnesses);

  const marketValStr = formatIndianCurrency(state.transaction.marketValue);
  const marketValWords = numberToIndianWords(state.transaction.marketValue);
  const oweltyAmount = state.transaction.considerationAmount || 0;
  const oweltyStr = formatIndianCurrency(oweltyAmount);
  const oweltyWords = numberToIndianWords(oweltyAmount);

  const dateStr = state.transaction.paymentDate || new Date().toISOString().split('T')[0];
  const parsedDate = new Date(dateStr);
  const formattedEnglishDate = isNaN(parsedDate.getTime())
    ? dateStr
    : parsedDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

  return [
    {
      id: 'title',
      titleEn: 'Deed Title',
      titleTa: 'பத்திரத் தலைப்பு',
      contentEn: '<h2 class="text-center font-bold underline text-slate-900 text-sm">DEED OF PARTITION</h2>',
      contentTa: '<h2 class="text-center font-bold underline text-slate-900 text-sm">பாகப்பிரிவினை பத்திரம்</h2>'
    },
    {
      id: 'intro',
      titleEn: 'Introductory Declaration',
      titleTa: 'அறிமுகப் பிரகடனம்',
      contentEn: `This DRAFT DEED OF PARTITION is prepared for execution at <strong>${escapeTemplateField(state.property.sro)}</strong> on this <strong>${formattedEnglishDate}</strong>.`,
      contentTa: `இந்த பாகப்பிரிவினை பத்திர வரைவு <strong>${escapeTemplateField(state.property.sro)}</strong> சார்பதிவக எல்லைக்குள் <strong>${formattedEnglishDate}</strong> அன்று எழுதப்பட்டது.`
    },
    {
      id: 'parties',
      titleEn: 'Description of Co-owners',
      titleTa: 'பாகஸ்தர்கள் விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>BY AND BETWEEN THE CO-OWNERS:</strong></p>
          <p>${party1Formatted.en}</p>
          <p class="font-bold py-1">AND</p>
          <p>${party2Formatted.en}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>பாகஸ்தர்கள் (கூட்டு உரிமையாளர்கள்) விவரம்:</strong></p>
          <p>${party1Formatted.ta}</p>
          <p class="font-bold py-1">மற்றும்</p>
          <p>${party2Formatted.ta}</p>
        </div>
      `
    },
    {
      id: 'recitals',
      titleEn: 'Recitals & Declared Joint Ownership History',
      titleTa: 'சொத்து வரலாறு & கூட்டு உரிமை விவரம்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>WHEREAS (AS REPRESENTED BY THE CO-OWNERS):</strong></p>
          <p>1. The CO-OWNERS declare that they hold joint title to the Scheduled Property described hereunder, citing acquisition or inheritance from <strong>${escapeTemplateField(state.ownershipHistory.priorOwners)}</strong>.</p>
          <p>2. Declared parent title record: Document No. <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)}</strong> of year <strong>${escapeTemplateField(state.ownershipHistory.parentDocYear)}</strong>, at SRO <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>.</p>
          <p>3. The Co-owners have mutually agreed to partition and divide the joint scheduled property in accordance with the terms set forth herein. ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>சொத்து வரலாறு விவரம் (பாகஸ்தர்கள் பிரகடனம்):</strong></p>
          <p>1. இப்பாகப்பிரிவினை பத்திரத்தில் விவரிக்கப்பட்டுள்ள சொத்தானது பாகஸ்தர்களுக்கு <strong>${escapeTemplateField(state.ownershipHistory.priorOwners)}</strong> வழி கூட்டு உரிமையாக உள்ளதாக அறிவிக்கப்படுகிறது.</p>
          <p>2. அறிவிக்கப்பட்ட முந்தைய ஆவண எண்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocNo)} / ${escapeTemplateField(state.ownershipHistory.parentDocYear)}</strong> (சார்பதிவகம்: <strong>${escapeTemplateField(state.ownershipHistory.parentDocSRO)}</strong>).</p>
          <p>3. பாகஸ்தர்கள் தங்களுக்குள் கூட்டுச் சொத்தினைப் பிரித்துக் கொள்ள பரஸ்பரம் உடன்பட்டுள்ளனர். ${escapeNarrative(state.ownershipHistory.historyNarrative)}</p>
        </div>
      `
    },
    {
      id: 'transaction',
      titleEn: 'Partition Terms & Declared Valuation',
      titleTa: 'பாகப்பிரிவினை விவரம் மற்றும் சொத்து மதிப்பு',
      contentEn: `
        <div class="space-y-2">
          <p>NOW THIS DEED WITNESSETH that the joint scheduled property is agreed to be partitioned between the FIRST PARTY (CO-OWNER) and the SECOND PARTY (CO-OWNER) as described in the Schedule hereunder.</p>
          <p>The declared total Market Value of the property under partition for stamp duty calculation is <strong>${marketValStr}</strong> (${marketValWords}). ${
            oweltyAmount > 0
              ? `Declared Owelty / Equalization Amount: <strong>${oweltyStr}</strong> (${oweltyWords}).`
              : 'No monetary equalization (owelty) is declared between the co-owners.'
          }</p>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதன்படி, கூட்டுச் சொத்தானது முதல் பாகஸ்தர் மற்றும் இரண்டாம் பாகஸ்தருக்கு இடையில் கீழ்க்கண்ட சொத்து விவர அட்டவணையின்படி பாகப்பிரிவினை செய்து கொள்ள உடன்படப்படுகிறது.</p>
          <p>முத்திரைத்தாள் கணக்கீட்டிற்காக அறிவிக்கப்பட்ட சொத்தின் மொத்த மதிப்பு <strong>${marketValStr}</strong> (${marketValWords}). ${
            oweltyAmount > 0
              ? `அறிவிக்கப்பட்ட சமன்பாட்டுத் தொகை: <strong>${oweltyStr}</strong> (${oweltyWords}).`
              : 'பாகஸ்தர்களுக்குள் எவ்வித பண ஈட்டுத் தொகையும் அறிவிக்கப்படவில்லை.'
          }</p>
        </div>
      `
    },
    {
      id: 'clauses',
      titleEn: 'Covenants & Clauses',
      titleTa: 'உடன்படிக்கைகள் மற்றும் நிபந்தனைகள்',
      contentEn: `
        <div class="space-y-2">
          <p><strong>THE CO-OWNERS MUTUALLY COVENANT AS FOLLOWS:</strong></p>
          ${clausesFormatted.en}
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p><strong>பாகஸ்தர்களின் உடன்படிக்கைகள் பின்வருமாறு:</strong></p>
          ${clausesFormatted.ta}
        </div>
      `
    },
    {
      id: 'schedule',
      titleEn: 'Property Schedule Description',
      titleTa: 'சொத்து அட்டவணை விவரம்',
      contentEn: scheduleFormatted.en,
      contentTa: scheduleFormatted.ta
    },
    {
      id: 'witnesses',
      titleEn: 'Witness Attestation Section',
      titleTa: 'சாட்சிகள் உறுதிப்பகுதி',
      contentEn: `
        <div class="space-y-2">
          <p>IN WITNESS WHEREOF, the FIRST PARTY (CO-OWNER) and the SECOND PARTY (CO-OWNER) have set their hands to this Partition Deed in the presence of the following witnesses:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.en}
          </div>
        </div>
      `,
      contentTa: `
        <div class="space-y-2">
          <p>இதற்குச் சாட்சியாக, பாகஸ்தர்கள் தங்களின் முழு சம்மதத்துடன் இப்பாகப்பிரிவினை பத்திரத்தில் கீழ் குறிப்பிட்ட சாட்சிகளின் முன்னிலையில் கையொப்பமிடுகின்றனர்:</p>
          <div class="mt-4 border-l-2 border-slate-300 pl-4">
            ${witnessesFormatted.ta}
          </div>
        </div>
      `
    },
    {
      id: 'signatures',
      titleEn: 'Signatures Block',
      titleTa: 'கையொப்பப் பகுதி',
      contentEn: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">FIRST PARTY (CO-OWNER)</p>
            <p className="text-slate-500 mt-8">Name: ${party1Formatted.collectiveEn}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">SECOND PARTY (CO-OWNER)</p>
            <p className="text-slate-500 mt-8">Name: ${party2Formatted.collectiveEn}</p>
          </div>
        </div>
      `,
      contentTa: `
        <div class="grid grid-cols-2 gap-8 pt-6 font-mono text-xs">
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">முதல் பாகஸ்தர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${party1Formatted.collectiveTa}</p>
          </div>
          <div class="border-t border-slate-300 pt-3">
            <p className="font-bold">இரண்டாம் பாகஸ்தர்</p>
            <p className="text-slate-500 mt-8">பெயர்: ${party2Formatted.collectiveTa}</p>
          </div>
        </div>
      `
    }
  ];
}
