/** Self-hosted Tamil font declarations for same-origin print windows. */
export function tamilPrintFontCss(origin: string): string {
 const safeOrigin = new URL(origin).origin;
 return [400, 700].map(weight => `@font-face { font-family: 'Noto Sans Tamil'; font-style: normal; font-weight: ${weight}; src: url('${safeOrigin}/fonts/noto-sans-tamil-tamil-${weight}-normal.woff2') format('woff2'); unicode-range: U+0964-0965,U+0B82-0BFA,U+200C-200D,U+20B9,U+25CC; }`).join('\n') + `.tamil, .tamil-text, .font-sans { font-family: 'Noto Sans Tamil', sans-serif; }`;
}
