import DOMPurify from 'dompurify';

const HTML_ESCAPE_MAP: Record<string, string> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
};

/**
 * Escapes plain-text user inputs before inserting them into HTML templates.
 * Converts &, <, >, ", and ' into safe HTML entities.
 */
export function escapeHtml(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value).replace(/[&<>"']/g, (char) => HTML_ESCAPE_MAP[char] || char);
}

/**
 * Permitted legal markup tags for bilingual Tamil Nadu deed drafting.
 */
const ALLOWED_LEGAL_TAGS = [
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'p', 'strong', 'b', 'em', 'i', 'u', 'sup', 'sub',
  'div', 'span', 'br', 'hr',
  'ul', 'ol', 'li',
  'table', 'thead', 'tbody', 'tr', 'th', 'td'
];

const ALLOWED_LEGAL_ATTRS = [
  'class', 'style', 'align', 'colspan', 'rowspan', 'border', 'cellpadding', 'cellspacing'
];

interface DOMPurifyInstance {
  sanitize: (dirty: string, config?: Record<string, unknown>) => string;
}

let activePurifier: DOMPurifyInstance | null = null;

function getBrowserSanitizer(): DOMPurifyInstance | null {
  if (activePurifier) return activePurifier;

  if (typeof window !== 'undefined') {
    const purify = (DOMPurify as unknown as { default?: unknown }).default || DOMPurify;
    if (purify && typeof (purify as DOMPurifyInstance).sanitize === 'function') {
      activePurifier = purify as DOMPurifyInstance;
    }
  }

  return activePurifier;
}

/**
 * Sets a custom DOMPurify instance (e.g., initialized with JSDOM on the server).
 */
export function setCustomSanitizer(purifier: DOMPurifyInstance | null): void {
  activePurifier = purifier;
}

/**
 * Client-safe HTML sanitizer for rich deed markup.
 * Uses native DOMPurify in browser environments.
 * If DOMPurify instance is unavailable or fails, fails closed by returning escaped HTML.
 */
export function sanitizeHtml(dirtyHtml: string): string {
  if (!dirtyHtml) return '';

  const sanitizer = getBrowserSanitizer();
  if (sanitizer && typeof sanitizer.sanitize === 'function') {
    try {
      return sanitizer.sanitize(dirtyHtml, {
        ALLOWED_TAGS: ALLOWED_LEGAL_TAGS,
        ALLOWED_ATTR: ALLOWED_LEGAL_ATTRS,
        FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'onfocus', 'onblur', 'onmouseenter', 'onmouseleave'],
        ALLOW_DATA_ATTR: false,
      });
    } catch {
      // Fail closed on runtime error during sanitization
      return escapeHtml(dirtyHtml);
    }
  }

  // Fail closed: return HTML-escaped string if sanitizer unavailable
  return escapeHtml(dirtyHtml);
}

/**
 * Sanitizes and normalizes an entire legal section (both English and Tamil content).
 */
export function sanitizeLegalSection<T extends { contentEn: string; contentTa: string }>(section: T): T {
  return {
    ...section,
    contentEn: sanitizeHtml(section.contentEn),
    contentTa: sanitizeHtml(section.contentTa),
  };
}
