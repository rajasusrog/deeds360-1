import { DeedWizardState, PartyDetails, WitnessDetails, SurveyDetails } from '../types';
import { resolveDeedType, partitionPartiesForDeedType, isDeedTemplateAvailable } from './deedTypes';

// ============================================================================
// 1. EXTERNAL CONNECTOR ARCHITECTURE
// ============================================================================

export interface ExternalConnector<TInput, TOutput> {
  id: string;
  name: string;
  providerName: string;
  version: string;
  description: string;
  verify(input: TInput): Promise<TOutput>;
}

// 1. UIDAI Aadhaar Gateway Connector (Format Check / Connector Stub)
export interface AadhaarVerificationResult {
  status: 'Format Pattern Matched (Not externally verified)' | 'Invalid_Format' | 'Suspicious';
  maskedAadhaar: string;
  isFormatValid: boolean;
  externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED';
  notice: string;
  errMessage?: string;
}

export class UIDAIAadhaarConnector implements ExternalConnector<string, AadhaarVerificationResult> {
  id = 'uidai-aadhaar-gateway';
  name = 'UIDAI Biometric & OTP Aadhaar Gateway';
  providerName = 'Unique Identification Authority of India (UIDAI)';
  version = '3.2-Deed360-Compatible';
  description = 'Direct OTP-based identity verification against national biometric archives.';

  async verify(aadhaar: string): Promise<AadhaarVerificationResult> {
    const clean = aadhaar.replace(/[\s-]/g, '');
    
    if (/^1111|^1234|^9999|^0000/.test(clean) || clean.length !== 12 || !/^\d{12}$/.test(clean)) {
      return {
        status: 'Suspicious',
        maskedAadhaar: 'XXXX-XXXX-invalid',
        isFormatValid: false,
        externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
        notice: 'Not externally verified with UIDAI biometric gateway.',
        errMessage: 'Format Warning: Sequence appears to be a placeholder or invalid 12-digit format.'
      };
    }
    
    return {
      status: 'Format Pattern Matched (Not externally verified)',
      maskedAadhaar: `XXXX-XXXX-${clean.substring(8)}`,
      isFormatValid: true,
      externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
      notice: 'Aadhaar 12-digit format is syntactically valid. Not externally verified with live UIDAI gateway.'
    };
  }
}

// 2. NSDL PAN Verification Connector (Format Check / Connector Stub)
export interface PanVerificationResult {
  status: 'Format Pattern Matched (Not externally verified)' | 'Invalid_Format';
  taxpayerName?: string;
  category?: string;
  isValidFormat: boolean;
  externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED';
  notice: string;
}

export class NsdlPanConnector implements ExternalConnector<string, PanVerificationResult> {
  id = 'nsdl-pan-taxpayer-query';
  name = 'NSDL Taxpayer & PAN Database Check';
  providerName = 'Protean eGov Technologies Limited (formerly NSDL)';
  version = 'v2.1';
  description = 'Cross-checks structural validity of the 10-character alphanumeric PAN key against CBDT registry rules.';

  async verify(pan: string): Promise<PanVerificationResult> {
    const upper = pan.trim().toUpperCase();
    if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(upper)) {
      return {
        status: 'Invalid_Format',
        isValidFormat: false,
        externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
        notice: 'PAN format invalid.'
      };
    }
    
    return {
      status: 'Format Pattern Matched (Not externally verified)',
      isValidFormat: true,
      taxpayerName: 'Format Valid (Not externally verified)',
      category: upper.charAt(3) === 'P' ? 'Individual' : 'Corporate / Firm',
      externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
      notice: 'PAN 10-character format is syntactically valid. Not externally verified with live NSDL CBDT database.'
    };
  }
}

// 3. Deed360 Guideline Database Connector (Format Check / Local Matrix)
export interface GuidelineQueryResult {
  guidelineValuePerSqft: number;
  marketSroDiscrepancy: boolean;
  status: 'Format Valid' | 'Under_Valued' | 'Unverified_Survey';
  externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED';
  notice: string;
}

export class TnreginetGuidelineConnector implements ExternalConnector<{ district: string; village: string; surveyNo: string }, GuidelineQueryResult> {
  id = 'tnreginet-guideline-service';
  name = 'TNreginet Deed360 Guideline Database Query';
  providerName = 'Tamil Nadu Registration Department (TNreginet)';
  version = 'Deed360-v4.9';
  description = 'Retrieves public registry land guideline valuations indexed by survey subdivision coordinates.';

  async verify(input: { district: string; village: string; surveyNo: string }): Promise<GuidelineQueryResult> {
    const { district, village } = input;
    const distLower = (district || '').toLowerCase();
    const villLower = (village || '').toLowerCase();

    let rate = 1500;
    if (villLower.includes('mylapore')) rate = 4500;
    else if (villLower.includes('chitlapakkam') || villLower.includes('tambaram')) rate = 2800;
    else if (distLower.includes('chennai')) rate = 3500;

    return {
      guidelineValuePerSqft: rate,
      marketSroDiscrepancy: false,
      status: 'Format Valid',
      externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
      notice: 'Guideline rate calculated from local benchmark tables. Not externally verified with live Deed360 SRO server.'
    };
  }
}

// 4. e-Sevai Patta Mutation Gateway (Format Check / Connector Stub)
export interface PattaRecordResult {
  status: 'Format Valid' | 'Mismatch' | 'Record_Not_Found';
  ownerNameEn: string;
  landClassification: 'Ryotwari Dry' | 'Ryotwari Wet' | 'Nanjai' | 'Punjai' | 'Grama Natham' | 'Prohibited / Government';
  totalExtentSqft: number;
  externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED';
  notice: string;
}

export class ESevaiPattaConnector implements ExternalConnector<{ pattaNo: string; village: string; surveyNo: string }, PattaRecordResult> {
  id = 'esevai-patta-mutation-service';
  name = 'e-Sevai Patta/Chitta Mutation Registry Gateway';
  providerName = 'Tamil Nadu Revenue Department (e-District / Any-Any)';
  version = 'v3.5';
  description = 'Verification of Land ownership record (ROR), Patta registers, and land classifications on Tamil Nadu revenue systems.';

  async verify(input: { pattaNo: string; village: string; surveyNo: string }): Promise<PattaRecordResult> {
    const patta = (input.pattaNo || '').trim();
    const key = `${input.surveyNo}`.trim();
    
    if (key === '142/3A' || key === '89/1B') {
      return {
        status: 'Mismatch',
        ownerNameEn: 'SRO EXCLUDED HOLDING / COURT INJUNCTION',
        landClassification: 'Prohibited / Government',
        totalExtentSqft: 0,
        externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
        notice: 'Prohibited survey list match detected in local rules engine.'
      };
    }

    if (!/^\d+$/.test(patta)) {
      return {
        status: 'Record_Not_Found',
        ownerNameEn: '',
        landClassification: 'Ryotwari Dry',
        totalExtentSqft: 0,
        externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
        notice: 'Patta number format not numeric. Not externally verified with live e-Sevai registry.'
      };
    }

    return {
      status: 'Format Valid',
      ownerNameEn: 'Format Valid (Not externally verified)',
      landClassification: 'Ryotwari Dry',
      totalExtentSqft: 2400,
      externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
      notice: 'Patta record structure valid. Not externally verified with live Tamil Nadu e-District portal.'
    };
  }
}

// 5. EC Registry Ledger Connector (Format Check / Connector Stub)
export interface EcVerificationResult {
  status: 'Format Valid' | 'Lien_Mortgage_Detected' | 'Double_Registration' | 'Unverified';
  ecPeriodYears: number;
  encumbranceDetails: string[];
  externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED';
  notice: string;
}

export class EcRegistryConnector implements ExternalConnector<{ parentDocNo: string; parentDocYear: string; surveyNo: string }, EcVerificationResult> {
  id = 'star20-ec-ledger-connector';
  name = 'Deed360 Encumbrance Certificate (EC) Ledger Connector';
  providerName = 'Tamil Nadu SRO Digital Encumbrance Archive';
  version = 'v2.8';
  description = 'Scans digital encumbrance index entries for prior mortgages, court attachments, or double-sales.';

  async verify(input: { parentDocNo: string; parentDocYear: string; surveyNo: string }): Promise<EcVerificationResult> {
    const parentNo = (input.parentDocNo || '').trim();

    if (!parentNo || parentNo === '————') {
      return {
        status: 'Unverified',
        ecPeriodYears: 0,
        encumbranceDetails: ['Missing Parent Deed coordinates. EC cannot trace title chain.'],
        externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
        notice: 'Parent deed coordinates missing.'
      };
    }

    return {
      status: 'Format Valid',
      ecPeriodYears: 30,
      encumbranceDetails: [],
      externalVerificationStatus: 'NOT_EXTERNALLY_VERIFIED',
      notice: 'Parent document reference formatted correctly. Not externally verified with live SRO Encumbrance Register.'
    };
  }
}

// ============================================================================
// 2. STRUCTURAL VERIFICATION RESULT TYPES
// ============================================================================

export interface VerificationModuleResult<TStatus = any> {
  status: TStatus;
  passed: boolean;
  details: string[];
  alerts: { message: string; severity: 'critical' | 'high' | 'moderate' | 'low'; fix: string }[];
}

export interface ComprehensiveVerificationResult {
  documentId?: string;
  evaluatedAt: string;

  // Distinct 4-Tier Verification Model
  inputValidation: {
    passed: boolean;
    checks: Array<{ field: string; status: 'VALID_FORMAT' | 'INVALID_FORMAT' | 'MISSING'; message: string }>;
  };
  internalConsistency: {
    passed: boolean;
    checks: Array<{ rule: string; status: 'CONSISTENT' | 'INCONSISTENT' | 'REVIEW_REQUIRED'; details: string }>;
  };
  aiObservations: {
    hasObservations: boolean;
    observations: Array<{ category: string; observation: string; suggestion?: string }>;
  };
  externalVerification: {
    status: 'NOT_EXTERNALLY_VERIFIED';
    connectedProviders: string[];
    details: string;
    evidence: Array<{ registry: string; status: 'NOT_EXTERNALLY_VERIFIED'; message: string }>;
  };

  // Module results for UI compatibility
  identityResult: VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'>;
  propertyResult: VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'>;
  ownershipResult: VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'>;
  financialResult: VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'>;
  fraudResult: VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'>;

  trustScore: number;
  trustBand: 'Format Valid' | 'Review Recommended' | 'Suspicious' | 'High Risk';
  scoreBreakdown: {
    identity: number;
    property: number;
    ownership: number;
    financial: number;
    fraud: number;
  };
}

// ============================================================================
// 3. MODULAR VERIFICATION ENGINES
// ============================================================================

export function verifyIdentity(state: DeedWizardState): VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'> {
  const details: string[] = [];
  const alerts: VerificationModuleResult['alerts'] = [];
  
  const parties = state.parties || [];
  const witnesses = state.witnesses || [];

  if (parties.length === 0) {
    alerts.push({
      message: 'No active executing parties assigned to this transaction.',
      severity: 'critical',
      fix: 'Navigate to Step 2 and add Buyer/Seller or Donor/Donee identities.'
    });
    return { status: 'Format Error', passed: false, details: ['Parties list is empty'], alerts };
  }

  let totalScore = 100;
  let placeholderCount = 0;
  let invalidPanCount = 0;

  parties.forEach((p, idx) => {
    const role = p.role || 'Party';
    const name = p.name || `Party #${idx + 1}`;
    
    if (p.pan) {
      if (/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(p.pan.toUpperCase())) {
        details.push(`PAN format valid for ${role}: ${name}`);
      } else {
        invalidPanCount++;
        totalScore -= 10;
        alerts.push({
          message: `Tax alert: Invalid PAN format "${p.pan}" for ${name}. Expected alphanumeric sequence (e.g. ABCDE1234F).`,
          severity: 'moderate',
          fix: 'Go to Step 2 and correct the PAN string according to standard Income Tax Department format.'
        });
      }
    } else {
      totalScore -= 5;
      alerts.push({
        message: `PAN ID missing for executing party ${name}.`,
        severity: 'high',
        fix: 'Provide the permanent account number in Step 2.'
      });
    }

    if (p.aadhaar) {
      const cleanAadhaar = p.aadhaar.replace(/[\s-]/g, '');
      const isPlaceholder = /^1111|^1234|^9999|^0000/.test(cleanAadhaar) || cleanAadhaar.length < 12;
      
      if (isPlaceholder) {
        placeholderCount++;
        totalScore -= 20;
        alerts.push({
          message: `Aadhaar format anomaly: Simulated/Placeholder Aadhaar ID "${p.aadhaar}" for ${name}.`,
          severity: 'critical',
          fix: 'Go to Step 2 and supply a 12-digit UIDAI identity string.'
        });
      } else {
        details.push(`Aadhaar 12-digit format valid (Masked) for ${role}: ${name}`);
      }
    } else {
      totalScore -= 10;
      alerts.push({
        message: `Aadhaar ID missing for executing party ${name}.`,
        severity: 'high',
        fix: 'Go to Step 2 and specify the 12-digit Aadhaar number.'
      });
    }

    if (p.phone) {
      if (/^[6-9][0-9]{9}$/.test(p.phone)) {
        details.push(`Mobile phone format valid for ${name} (${p.phone}) (Not externally verified via OTP)`);
      } else {
        totalScore -= 5;
        alerts.push({
          message: `Mobile format anomaly for ${name}: Phone "${p.phone}" must contain exactly 10 digits starting with 6-9.`,
          severity: 'moderate',
          fix: 'Correct the mobile phone entry in Step 2.'
        });
      }
    } else {
      totalScore -= 10;
      alerts.push({
        message: `Mobile phone missing for ${name}.`,
        severity: 'high',
        fix: 'Input the executing party phone number in Step 2.'
      });
    }
  });

  if (witnesses.length < 2) {
    totalScore -= 15;
    alerts.push({
      message: `Attestation Warning: Found ${witnesses.length} witness(es). Legal deeds require a minimum of two signing witnesses.`,
      severity: 'high',
      fix: 'Add at least 2 independent witnesses in Step 9.'
    });
  } else {
    details.push(`Attestation quorum satisfied (${witnesses.length} witnesses specified)`);
  }

  let status: 'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious' = 'Format Valid';
  if (placeholderCount > 0) status = 'Suspicious';
  else if (invalidPanCount > 0 || witnesses.length < 2) status = 'Partially Valid';

  return {
    status,
    passed: status === 'Format Valid' || status === 'Partially Valid',
    details,
    alerts
  };
}

export function verifyProperty(state: DeedWizardState): VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'> {
  const details: string[] = [];
  const alerts: VerificationModuleResult['alerts'] = [];
  
  const prop = state.property || {};
  const surv = state.survey || {};

  if (!prop.district || !prop.village || !prop.sro) {
    alerts.push({
      message: 'Property Jurisdiction Incomplete: Missing District, Village, or SRO assignment.',
      severity: 'high',
      fix: 'Set District, Taluk, Village, and SRO in Step 3.'
    });
  } else {
    details.push(`Jurisdiction mapped: SRO ${prop.sro}, Village ${prop.village}, District ${prop.district}`);
  }

  if (!surv.surveyNo) {
    alerts.push({
      message: 'Survey Coordinates Missing: Primary survey number is empty.',
      severity: 'critical',
      fix: 'Specify primary survey number in Step 4.'
    });
  } else {
    details.push(`Primary Survey No: ${surv.surveyNo} / SubDivision: ${surv.subDivision || 'N/A'}`);
  }

  const currentSurveyRef = `${surv.surveyNo}/${surv.subDivision}`.trim();
  if (currentSurveyRef === '89/1B' || currentSurveyRef === '142/3A' || currentSurveyRef === '55/2') {
    alerts.push({
      message: `Prohibited Property Alert: Survey ${currentSurveyRef} matches Section 22-A prohibited land watchlists.`,
      severity: 'critical',
      fix: 'Verify Revenue Department clearance before proceeding with document generation.'
    });
  }

  let status: 'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious' = 'Format Valid';
  if (currentSurveyRef === '89/1B' || currentSurveyRef === '142/3A') status = 'Suspicious';
  else if (alerts.length > 0) status = 'Partially Valid';

  return {
    status,
    passed: status === 'Format Valid' || status === 'Partially Valid',
    details,
    alerts
  };
}

export function verifyOwnershipChain(state: DeedWizardState): VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'> {
  const details: string[] = [];
  const alerts: VerificationModuleResult['alerts'] = [];
  
  if (!isDeedTemplateAvailable(state?.documentType)) {
    alerts.push({
      message: `Template unavailable for document type "${state?.documentType || 'Unspecified'}". Generation and export are blocked.`,
      severity: 'critical',
      fix: 'Select a supported document type (Sale, Settlement, Gift, Partition, Lease, Mortgage, POA).'
    });
  }

  const history = state.ownershipHistory || {};

  if (!history.parentDocNo || history.parentDocNo === '————') {
    alerts.push({
      message: 'Parent Title Document Missing: No prior Document Reference specified.',
      severity: 'high',
      fix: 'Specify the registered Parent Document Number, Year, and SRO in Step 7.'
    });
  } else {
    details.push(`Parent Document Ref: Doc No ${history.parentDocNo} (${history.parentDocYear || 'Year N/A'}) at SRO ${history.parentDocSRO || 'N/A'}`);
  }

  let status: 'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious' = 'Format Valid';
  if (alerts.some(a => a.severity === 'critical')) status = 'Format Error';
  else if (alerts.some(a => a.severity === 'high')) status = 'Partially Valid';

  return {
    status,
    passed: status === 'Format Valid' || status === 'Partially Valid',
    details,
    alerts
  };
}

export function verifyFinancials(state: DeedWizardState): VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'> {
  const details: string[] = [];
  const alerts: VerificationModuleResult['alerts'] = [];
  
  if (!isDeedTemplateAvailable(state?.documentType)) {
    alerts.push({
      message: `Template unavailable for document type "${state?.documentType || 'Unspecified'}". Generation and export are blocked.`,
      severity: 'critical',
      fix: 'Select a supported document type (Sale, Settlement, Gift, Partition, Lease, Mortgage, POA).'
    });
  }

  const tx = state.transaction || {};
  const consideration = Number(tx.considerationAmount) || 0;
  const guideline = Number(tx.guidelineValue) || 0;

  if (consideration > 0) {
    details.push(`Declared Consideration Amount: ₹ ${consideration.toLocaleString('en-IN')}`);
  } else {
    alerts.push({
      message: 'Consideration Amount Unspecified or Zero.',
      severity: 'high',
      fix: 'Enter transaction consideration sum in Step 8.'
    });
  }

  if (guideline > 0 && consideration < guideline) {
    alerts.push({
      message: `Undervaluation Alert: Declared consideration (₹ ${consideration.toLocaleString('en-IN')}) is lower than Guideline Value (₹ ${guideline.toLocaleString('en-IN')}).`,
      severity: 'critical',
      fix: 'Adjust consideration amount to match or exceed guideline value in Step 8.'
    });
  }

  let status: 'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious' = 'Format Valid';
  if (alerts.some(a => a.severity === 'critical')) status = 'Format Error';
  else if (alerts.some(a => a.severity === 'high')) status = 'Partially Valid';

  return {
    status,
    passed: status === 'Format Valid' || status === 'Partially Valid',
    details,
    alerts
  };
}

export function detectFraudSignals(state: DeedWizardState): VerificationModuleResult<'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious'> {
  const details: string[] = [];
  const alerts: VerificationModuleResult['alerts'] = [];

  const parties = state.parties || [];
  
  // Check duplicate phone / aadhaar across different roles
  const phones = new Set<string>();
  parties.forEach(p => {
    if (p.phone) {
      if (phones.has(p.phone)) {
        alerts.push({
          message: `Phone Number Reuse: Phone ${p.phone} is assigned to multiple distinct parties.`,
          severity: 'high',
          fix: 'Ensure each party provides a distinct mobile phone number in Step 2.'
        });
      } else {
        phones.add(p.phone);
      }
    }
  });

  if (alerts.length === 0) {
    details.push('No internal duplicate phone or identity conflicts detected in party list.');
  }

  let status: 'Format Valid' | 'Partially Valid' | 'Format Error' | 'Suspicious' = 'Format Valid';
  if (alerts.some(a => a.severity === 'critical' || a.severity === 'high')) status = 'Partially Valid';

  return {
    status,
    passed: true,
    details,
    alerts
  };
}

// ============================================================================
// 4. COMPREHENSIVE 4-TIER VERIFICATION SCORE
// ============================================================================

export function calculateTrustScore(state: DeedWizardState): ComprehensiveVerificationResult {
  const identity = verifyIdentity(state);
  const property = verifyProperty(state);
  const ownership = verifyOwnershipChain(state);
  const financial = verifyFinancials(state);
  const fraud = detectFraudSignals(state);

  // Score breakdown (Max 100)
  let identityScore = identity.passed ? (identity.status === 'Format Valid' ? 25 : 18) : 5;
  let propertyScore = property.passed ? (property.status === 'Format Valid' ? 25 : 18) : 5;
  let ownershipScore = ownership.passed ? (ownership.status === 'Format Valid' ? 20 : 14) : 4;
  let financialScore = financial.passed ? (financial.status === 'Format Valid' ? 15 : 10) : 3;
  let fraudScore = fraud.passed ? (fraud.status === 'Format Valid' ? 15 : 10) : 2;

  const trustScore = identityScore + propertyScore + ownershipScore + financialScore + fraudScore;

  let trustBand: 'Format Valid' | 'Review Recommended' | 'Suspicious' | 'High Risk' = 'Format Valid';
  if (trustScore < 50) trustBand = 'High Risk';
  else if (trustScore < 70) trustBand = 'Suspicious';
  else if (trustScore < 88) trustBand = 'Review Recommended';

  // Distinct 4-Tier Verification Model Output
  const inputValidation = {
    passed: identity.passed && property.passed,
    checks: [
      {
        field: 'Parties & Witnesses',
        status: (identity.passed ? 'VALID_FORMAT' : 'INVALID_FORMAT') as 'VALID_FORMAT' | 'INVALID_FORMAT',
        message: identity.passed ? 'Party syntax and attestation quorum format valid.' : 'Parties or witnesses list incomplete.'
      },
      {
        field: 'Survey Coordinates',
        status: (property.passed ? 'VALID_FORMAT' : 'INVALID_FORMAT') as 'VALID_FORMAT' | 'INVALID_FORMAT',
        message: property.passed ? 'Survey coordinates and subdivision format valid.' : 'Survey coordinates missing or malformed.'
      }
    ]
  };

  const internalConsistency = {
    passed: ownership.passed && financial.passed,
    checks: [
      {
        rule: 'Consideration vs Guideline Value',
        status: (financial.passed ? 'CONSISTENT' : 'INCONSISTENT') as 'CONSISTENT' | 'INCONSISTENT',
        details: financial.details[0] || 'Consideration check evaluated.'
      },
      {
        rule: 'Parent Deed Chain Tracking',
        status: (ownership.passed ? 'CONSISTENT' : 'REVIEW_REQUIRED') as 'CONSISTENT' | 'REVIEW_REQUIRED',
        details: ownership.details[0] || 'Parent deed reference evaluated.'
      }
    ]
  };

  const aiObservations = {
    hasObservations: fraud.alerts.length > 0,
    observations: fraud.alerts.map(a => ({
      category: 'Risk Analysis',
      observation: a.message,
      suggestion: a.fix
    }))
  };

  const externalVerification = {
    status: 'NOT_EXTERNALLY_VERIFIED' as const,
    connectedProviders: [],
    details: 'No live external government API provider (UIDAI, NSDL, Deed360 SRO, Revenue Patta) is currently connected.',
    evidence: [
      {
        registry: 'UIDAI Aadhaar Portal',
        status: 'NOT_EXTERNALLY_VERIFIED' as const,
        message: 'Format Valid. Not externally verified with live UIDAI gateway.'
      },
      {
        registry: 'NSDL CBDT PAN Database',
        status: 'NOT_EXTERNALLY_VERIFIED' as const,
        message: 'Format Valid. Not externally verified with live NSDL tax registry.'
      },
      {
        registry: 'TNreginet SRO Deed360',
        status: 'NOT_EXTERNALLY_VERIFIED' as const,
        message: 'Format Valid. Not externally verified with live Sub-Registrar Office ledger.'
      }
    ]
  };

  return {
    evaluatedAt: new Date().toISOString(),
    inputValidation,
    internalConsistency,
    aiObservations,
    externalVerification,
    identityResult: identity,
    propertyResult: property,
    ownershipResult: ownership,
    financialResult: financial,
    fraudResult: fraud,
    trustScore,
    trustBand,
    scoreBreakdown: {
      identity: identityScore,
      property: propertyScore,
      ownership: ownershipScore,
      financial: financialScore,
      fraud: fraudScore
    }
  };
}
