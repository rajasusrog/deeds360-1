import { PropertyDetails, SurveyDetails, ExtentDetails, BoundaryDetails } from '../types';
import { escapeHtml } from './htmlSanitizer';

export interface FormattedScheduleOutput {
  en: string;
  ta: string;
}

/**
 * Formats a list of survey numbers and details safely with HTML escaping.
 */
function formatSurveys(surveys: SurveyDetails[], isTa = false): string {
  if (!surveys || surveys.length === 0) {
    return isTa ? '[சர்வே விவரங்கள் இன்னும் உள்ளிடப்படவில்லை]' : '[No Survey details provided]';
  }

  return surveys.map((s, idx) => {
    const surveyPrefix = isTa ? `வரிசை எண் ${idx + 1}: சர்வே எண்` : `Record ${idx + 1}: Survey No.`;
    const subDivWord = isTa ? 'உட்பிரிவு' : 'Sub-Division';
    const pattaWord = isTa ? 'பட்டா எண்' : 'Patta No.';
    const tslrWord = isTa ? 'TSLR எண்' : 'TSLR No.';
    const chittaWord = isTa ? 'சிட்டா குறிப்பு' : 'Chitta Ref.';

    const safeSurveyNo = escapeHtml(s.surveyNo || '————');
    const safeSubDiv = s.subDivision ? escapeHtml(s.subDivision) : '';
    const safePatta = s.pattaNo ? escapeHtml(s.pattaNo) : '';
    const safeTslr = s.tslrNo ? escapeHtml(s.tslrNo) : '';
    const safeChitta = s.chittaRef ? escapeHtml(s.chittaRef) : '';

    const parts = [
      `<strong>${safeSurveyNo}</strong>`,
      safeSubDiv ? `${subDivWord} <strong>${safeSubDiv}</strong>` : '',
      safePatta ? `${pattaWord} <strong>${safePatta}</strong>` : '',
      safeTslr ? `${tslrWord} <strong>${safeTslr}</strong>` : '',
      safeChitta ? `${chittaWord} <strong>${safeChitta}</strong>` : ''
    ].filter(Boolean);

    return `${surveyPrefix} ${parts.join(', ')}`;
  }).join('<br/>');
}

/**
 * Formats boundaries beautifully and safely with HTML escaping
 */
function formatBoundaries(boundary: BoundaryDetails, isTa = false): string {
  if (!boundary) return '';
  const east = escapeHtml(boundary.east || '————');
  const west = escapeHtml(boundary.west || '————');
  const north = escapeHtml(boundary.north || '————');
  const south = escapeHtml(boundary.south || '————');

  if (isTa) {
    return `
      <strong>கிழக்கு:</strong> ${east}<br/>
      <strong>மேற்கு:</strong> ${west}<br/>
      <strong>வடக்கு:</strong> ${north}<br/>
      <strong>தெற்கு:</strong> ${south}
    `;
  }
  return `
    <strong>East by:</strong> ${east}<br/>
    <strong>West by:</strong> ${west}<br/>
    <strong>North by:</strong> ${north}<br/>
    <strong>South by:</strong> ${south}
  `;
}

/**
 * Formats extent values beautifully and safely with HTML escaping
 */
export function formatExtent(extent: ExtentDetails, isTa = false): string {
  if (!extent) return '';
  const safeSqft = escapeHtml(extent.sqft || '');
  const safeCent = extent.cent ? escapeHtml(extent.cent) : '';
  const safeAcre = extent.acre ? escapeHtml(extent.acre) : '';
  const safeHectare = extent.hectare ? escapeHtml(extent.hectare) : '';
  const safeBuiltUp = extent.builtUpArea ? escapeHtml(extent.builtUpArea) : '';
  const safeUds = extent.uds ? escapeHtml(extent.uds) : '';
  const safeEastWest = escapeHtml(extent.eastWest || '————');
  const safeNorthSouth = escapeHtml(extent.northSouth || '————');

  if (isTa) {
    const mainExtent = safeSqft ? `${safeSqft} சதுர அடி (Sq.Ft)` : '';
    const otherExtent = [];
    if (safeCent) otherExtent.push(`${safeCent} சென்ட் (Cent)`);
    if (safeAcre) otherExtent.push(`${safeAcre} ஏக்கர் (Acre)`);
    if (safeHectare) otherExtent.push(`${safeHectare} ஹெக்டேர் (Hectare)`);
    
    let result = mainExtent;
    if (otherExtent.length > 0) {
      result += ` [சமமான விஸ்தீரணம்: ${otherExtent.join(', ')}]`;
    }
    
    if (safeBuiltUp) {
      result += `<br/><strong>கட்டிட விஸ்தீரணம்:</strong> ${safeBuiltUp} சதுர அடி`;
    }
    if (safeUds) {
      result += `<br/><strong>பிரிபடாத பாகம் (UDS):</strong> ${safeUds} சதுர அடி`;
    }
    if (extent.eastWest || extent.northSouth) {
      result += `<br/><strong>அளவுகள்:</strong> கிழக்கு-மேற்கு: ${safeEastWest}, வடக்கு-தெற்கு: ${safeNorthSouth}`;
    }
    return result;
  } else {
    const mainExtent = safeSqft ? `${safeSqft} Sq.Ft` : '';
    const otherExtent = [];
    if (safeCent) otherExtent.push(`${safeCent} Cents`);
    if (safeAcre) otherExtent.push(`${safeAcre} Acres`);
    if (safeHectare) otherExtent.push(`${safeHectare} Hectares`);

    let result = mainExtent;
    if (otherExtent.length > 0) {
      result += ` (equivalent to ${otherExtent.join(', ')})`;
    }

    if (safeBuiltUp) {
      result += `<br/><strong>Built-up Area:</strong> ${safeBuiltUp} Sq.Ft`;
    }
    if (safeUds) {
      result += `<br/><strong>Undivided Share of Land (UDS):</strong> ${safeUds} Sq.Ft`;
    }
    if (extent.eastWest || extent.northSouth) {
      result += `<br/><strong>Dimensions:</strong> East-West: ${safeEastWest}, North-South: ${safeNorthSouth}`;
    }
    return result;
  }
}

/**
 * Formats property description schedule for both English and Tamil safely with HTML escaping
 */
export function generatePropertySchedule(
  property: PropertyDetails,
  survey: SurveyDetails,
  surveysList: SurveyDetails[] | undefined,
  extent: ExtentDetails,
  boundary: BoundaryDetails,
  scheduleTitleEn = 'SCHEDULE OF THE PROPERTY (SCHEDULE "A")',
  scheduleTitleTa = 'சொத்து விவர அட்டவணை (அட்டவணை "A")'
): FormattedScheduleOutput {
  const activeSurveys = surveysList && surveysList.length > 0 ? surveysList : [survey];

  const safeDoor = property.doorNo ? escapeHtml(property.doorNo) : '';
  const safeRegDist = escapeHtml(property.registrationDistrict || '————');
  const safeDist = escapeHtml(property.district || '————');
  const safeSro = escapeHtml(property.sro || '————');
  const safeVillage = escapeHtml(property.village || '————');
  const safeTaluk = escapeHtml(property.taluk || '————');
  const safeWard = property.ward ? escapeHtml(property.ward) : '';
  const safeBlock = property.block ? escapeHtml(property.block) : '';
  const safeType = escapeHtml(property.propertyType || 'Residential Plot');
  const safeTitleEn = escapeHtml(scheduleTitleEn);
  const safeTitleTa = escapeHtml(scheduleTitleTa);

  const enHTML = `
    <div class="space-y-4 text-xs leading-relaxed font-sans">
      <p class="text-center font-bold underline uppercase tracking-wide text-slate-800">
        ${safeTitleEn}
      </p>
      <p>
        All that piece and parcel of land and property bearing 
        ${safeDoor ? `Door/Plot No. <strong>${safeDoor}</strong>` : 'Property'}, 
        situated within the Registration District of <strong>${safeRegDist}</strong>, 
        Revenue District of <strong>${safeDist}</strong>, 
        Sub-Registration District of <strong>${safeSro}</strong>, 
        situated at Village <strong>${safeVillage}</strong>, 
        under Taluk <strong>${safeTaluk}</strong>, 
        ${safeWard ? `Ward: <strong>${safeWard}</strong>` : ''} 
        ${safeBlock ? `Block: <strong>${safeBlock}</strong>` : ''} 
        registered as property type <strong>${safeType}</strong>, and bounded as follows:
      </p>

      <div class="border border-slate-200 bg-slate-50/50 p-3 rounded space-y-2">
        <div>
          <span class="font-bold text-slate-700 block mb-1">Land Surveys & Patta Records:</span>
          ${formatSurveys(activeSurveys, false)}
        </div>
        <div class="border-t border-slate-200/60 pt-2">
          <span class="font-bold text-slate-700 block mb-0.5">Total Extent:</span>
          ${formatExtent(extent, false)}
        </div>
      </div>

      <div class="border border-slate-200 bg-slate-50/50 p-3 rounded">
        <span class="font-bold text-slate-700 block mb-1">Bounded By (Four Boundaries):</span>
        ${formatBoundaries(boundary, false)}
      </div>
    </div>
  `;

  const taHTML = `
    <div class="space-y-4 text-xs leading-relaxed font-sans">
      <p class="text-center font-bold underline uppercase tracking-wide text-slate-800">
        ${safeTitleTa}
      </p>
      <p>
        <strong>${safeRegDist}</strong> பதிவு மாவட்டம், 
        <strong>${safeDist}</strong> வருவாய் மாவட்டம், 
        <strong>${safeSro}</strong> சார்பதிவக எல்லைக்குட்பட்ட, 
        <strong>${safeTaluk}</strong> வட்டம், 
        <strong>${safeVillage}</strong> கிராமத்தில் அமைந்ததும், 
        ${safeDoor ? `கதவு/மனை எண் <strong>${safeDoor}</strong>` : 'சொத்து'} கொண்டதும், 
        ${safeWard ? `வார்டு: <strong>${safeWard}</strong>` : ''} 
        ${safeBlock ? `பிளாக்: <strong>${safeBlock}</strong>` : ''} 
        <strong>${safeType}</strong> வகையைச் சார்ந்ததுமான கீழ் குறிப்பிட்ட நான்கு எல்லைகளுக்கு உட்பட்ட சொத்து:
      </p>

      <div class="border border-slate-200 bg-slate-50/50 p-3 rounded space-y-2">
        <div>
          <span class="font-bold text-slate-700 block mb-1">வருவாய் நில அளவை மற்றும் பட்டா விவரங்கள்:</span>
          ${formatSurveys(activeSurveys, true)}
        </div>
        <div class="border-t border-slate-200/60 pt-2">
          <span class="font-bold text-slate-700 block mb-0.5">சொத்தின் மொத்த அளவுகள் & விஸ்தீரணம்:</span>
          ${formatExtent(extent, true)}
        </div>
      </div>

      <div class="border border-slate-200 bg-slate-50/50 p-3 rounded">
        <span class="font-bold text-slate-700 block mb-1">நான்கு எல்லைகள் விபரம்:</span>
        ${formatBoundaries(boundary, true)}
      </div>
    </div>
  `;

  return {
    en: enHTML,
    ta: taHTML
  };
}
